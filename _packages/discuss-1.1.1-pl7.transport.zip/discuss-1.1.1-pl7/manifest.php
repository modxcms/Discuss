<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl7/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'aed4b8b98c5aed381953d0a60c442fb3',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/2fa4cbe60f14c238486dc0a5dbb153bf.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '078d38a04f525bc011261e5952bd6654',
      'native_key' => 1,
      'filename' => 'modCategory/8d15d10ff6534ecc25dfe3c21aec8dda.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c3e1e305229cd2e0a535f203ef3e2345',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/a5e28f7e360dbe0782c330fbede1d915.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5aa716977081f0511eec8fbb3d454482',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/ea715aeb1b5e7129e7b5b6801803bc1a.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '881b320e4bf78713e733bf5244a5a763',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/98a8f43228d076b57dbe357d2bcc16b2.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6c4c6cf0b15b2a84515816f5feb50d83',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ea72ead0cd363b634f0fd357cd42076a.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '440d996f289ed0c9170d4c664352df37',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/b0100043b0bcf46b65a26f9ada415b35.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fecec03375288753cbab80f0b237ece',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/0680496dd8ef85a87dd9886e75360c04.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '380b99e89cce623c8db0749366b79945',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/cbef62dd53cd858dd3f6d41370955fce.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '794de4cd8e63866d8bda75bb0558a2a3',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/d412de351b0fe7004b32a18a006d23b0.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fb7fc1d22f3f5b185189807d74ab98e',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/7c70176a8bdbe5c0bc334ea429e26046.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '786538212b9a5666c56c7b3c65cbd8f7',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/33a84ed11e212625d471305220c2e157.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fd5a0bb0e2612e765b303b537d0c2aa',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/4d18ae902a1afc8fe76d49f8f1d221fd.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc2eb4a01a9c7779bd473304fe4d5bef',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/521d8563c540e51a7917f588cdfd825f.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb2c318bf22c7888442d9d1712723064',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/a6dea4d1da7f06de58f54cd48c674fad.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4e067a6f12a7b5c4cd77e769ae3ca98',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/f5c226fdf2949ff62c359492380b3eee.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2050defb3ed4aa57bea9c5a699aa451a',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/898b7b6bae5bfaa3be43dc0573ce6794.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24c6f874780c84cb2ee239b2b7e5e391',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/ac98d1d67dc10bb74fc526d224340be2.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '438f3af2d1b162fa789e6159a5f0989c',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/c0df0070ec3405b1414b80303d38846b.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae705913ebcd9f64591b116f24743657',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/13c0461e51e0a97b3ec0487a8db227a6.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75067ae96cc47350933c6c5f17f18f30',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/34dd5c3ce6cdf9eee924d54ecacb2b56.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f60caf7e3a64f2758a9a560c13e4920',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/db3d7435b314d7cea04d8f0fafe9643d.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cbaaf91fc57f9e36a7bbbf018b1b200',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/961eaa80d170d30b18825fa5249970bd.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bab462b7dd256adb90d6a79a921ea1d0',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/7b80e851ee48d3b8a066d5deaa6360b0.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e927ee722f6f247964c77f58a24c1e0',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/a5a1907ec20593b82d4ff055d119ecfb.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e83964807f28958bffa2cde1fbad734f',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/ea8f9d5a6f4f46ff8485110569346496.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b6b93c84ce0d043a10750e2aa4b9973',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/26f7e8009b62ec58406c9701d54ee7db.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd700514fb1a7550e9b5bff168984a76',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/559ee321a7b1fb4056b38bd17419dd52.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cf253dfa590188e031d1d989b55769c',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/acbe926a47ee4476817ed8fed582d77d.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c49d9603ad09e825ddf182db8709b45b',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/9ce18e2ddc23fc072fffe5fb0eedb220.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e87720e53f6e602a1d3b7cbd623ea729',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/c0b1ec18bef7bb404b0bafab233fe2dc.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a882a87c5c20049983ca9d51b06ff75',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/b8521d06288832ab9433572b8473b9c9.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6e0d281e715ad5aff7fb9441464a103',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/1de11c1adab762dfa0ff2f4a29658ab9.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '209defaf1c56475199ba49dcbad70027',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/f6d3d35e376ca3c86438b298140be100.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed62fd2ab401527c4308313bc9864a76',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/80b1d4c88f2addf8ee2ab595522732db.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7da9fafe06fded99ca866b34fdd3812a',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/763d6140ce2061b5272c9de6b54561fd.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5c36e03e6eb3b8cd4129ec5dda66a16',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/9c0ca16e77dadafccb29b299543173f5.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33f937c87b311e9c709f6af70fdc6c39',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/08f077121681a5f63d31f57645d6e516.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96742226cef55077d05d9f4ff1ea586a',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/7fa6096c643d3e396bda18555d42dfdb.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc7c03934d5db636eb99c9e4eb5b3e1a',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/a5b3c34aa3ec720df6545ffac5724a38.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b9bba41515aa63cd2bd48f95c490308',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/7ea033fce074f8acbd2adc66f320a9ad.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f27005f68a07602f08285c63948f3ff',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/fe89648d02d498799afecbaf8207b483.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c0929fc08658082ada2eca4fb0c9420',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/fab1632f035fd5bf7ee70a2782c90467.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e435dd153adac2aa92ec62011a3ea35d',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/fa73d3a2d0a90103760b6157ad0167b6.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a2a0ad550e927b411210925bec06c63',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/661c5157ad7397353e6a923a616f7377.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c77c8a6ba2f210e5bebde3aa1848e46',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/f03233dfcda959fa4bb8cf1e31240280.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e67f91bf3342cc3735f3bf15f38545f3',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/09481e8a6a3ad6c4f887ff119e229e91.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53916057a9b5d3e5e13210f76bc4002e',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/1c5dd51f8e1f03da26c14b307370b087.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '505559d648bd1868538cf51b84034fb5',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/13af39d62555dab900e28c19f0b2c192.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11ea2ba64cc3ee4ca0d88365dcdcfb01',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/e6d42571d2bc0eb083dd9232c14c7136.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e71cacafb75f7fe7ae2bd54875ca8c2',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/9d892e7c71db1bd30cd44bcf22558865.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12764b80ad026a007236ab9bd16356f6',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/92fa1b1de417d56cb2fa41e53ecb6edc.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddaa22fbcdf652f53d85831d878bf08f',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/6de32f7a5aafb1af89e1a0bf71c92f19.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0491643bc83d3453356244f55441b131',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/e884a91dea747188a6960e816d1b39d3.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5514bf4831b55780171cdce62d8b24ca',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/67d76f7669f477e9f11ba7e5bb4c9ec3.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aab8da472c0ea9516dc15efd1faf0c46',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/4ae239863ab8a7979a8302d4e3f3b6a5.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51ff44e723ad8eb29daad27e35a5a226',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/00480d197e967423eb4c1771ea34c2a9.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a9bf9a5a4fe9b7e96f326ef6a8761d1',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/bbd55529e51106a0fe9dbcc106fe43f8.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36244425ed42f14b029c25acb08a43cb',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/1b918401a9dd968b4a7c7b97aa3907f9.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c6bc495ed7228ce2f1a1de79b3347be',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/d2762712a268e5b162854053eabc06f8.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18d9e73fdf07c4fcd94dd02ae7551327',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/3b0800c18ff28823158f7d3059d15bb1.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '255f172c7cd411bb0a800943aa0fe4bd',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/50fc66bd400e765867df45f1a32eba4c.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1c4c74ee16c41a54a36c0bce9f6c98a',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/26854dd7b5ff346c13f05485e1f8b2d6.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5b9eb22bcae6ccf3e5efbc2e22ff9e8',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/51ef2580cb3d92e21a42335fb72e05f9.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4096e001928da748efe99995e030d2a9',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/5be4638c2a6582e791aaf70c3b49463a.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0bb9746b437f6225fa4979adf0cca4b',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/ad8c9bcfd0875c40aabfc0e9f523ade8.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '457c28ae34f3b91f7ae718cbd0a7f9a2',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/ec96296a000fd7cbc8c6252a5d93ba22.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c2ac2ee30d0824e699c52356e47ae0b',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/2b321785d2c3ba7e494607b8450eb0c6.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9107de60a8b7b0075fcc7082c07f0d5',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/3635cd26a0643c8adf492363171cadeb.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6fd6e69a06582df11102060998906a1',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/26695eaa663b3bb67cac9638e289e23f.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f361ccf0b9efb41c105d45e65587b418',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/9cf617a925b249508b2aa5b1c54cfe09.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceff1f7830a00070129411c777c27ca8',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/370959c729cb027bf3fed66eefcfec18.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e79c1f7019982b717887615c96864674',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/8540a3a6e70194729ebe07902a5e2991.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbc0fb7751ef5f3e46d7bc6f066afac5',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/1c0c641afded8d8f0a41ecb2f6864ea0.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51589173254a2bddad2087e8c406c5fe',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/a586d578c207712fefc76f9a139964c0.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67287d9e74ff96881f4e15ad845aa796',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/134a8afb6f0487869a338a9433c0941f.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '746d1dc1840d581d04be791b640f4b04',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/70985d3a1afe08d6625acafc731d214a.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38a739755e11f44e1af8437da30a0035',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/77be89b40300b2a76b40ed825eddd542.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b572c20fcd338c63785e73cfdffefbf',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/a1e4aaa5913b99cd5ec5af49444f8299.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96612d32c6e7faf8f9f100356ea46d90',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/d20e6b9dc0b75a61e496023e8a5576fe.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9305c612e4a23d1bcf41c09ee737aa6c',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/902b6128019e06a40b4f3490900d506a.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd87b919af5607fb33af6b74c5753f2a3',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/e59c722b08728028515fcfdb67f5d0ad.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '043993eb2513c91166cd8a23077d71ad',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/415775aab25e4d1c5f0fa053ac6a8f1b.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f8fe67b59c9914552c386cc071df298',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/f5e942a2289aec690b589271846ce4de.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '37a5263c3102d2a4d68b8884ff55c930',
      'native_key' => NULL,
      'filename' => 'modUserGroup/0c8ddad5decfbcc58fd9b61dddc06d86.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'dc77d2ab0dc910b8e25c4966cf0b898f',
      'native_key' => NULL,
      'filename' => 'modUserGroup/e39510a8fac5ce61e314cf2ca1ccd254.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56c91e3b96df1a005326719f9df8a01a',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/10098c12b420112a29caaa543eca86e2.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e907c0c592b311091f02530cd75da5a',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/f8acf8999139b8b9211b7265f81ef67c.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '090bf47d102422bd83c603c54a19fa93',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/e06126c8cebf87db956025cc49d5e4e0.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1255e9478ecce037f5905aa826c8ba6a',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/f57a0618875bf09a8085bd7a0117fc88.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80b7d2cb3b8a388f60ddad255534918e',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/bb8809d128c6abed412079e845ac4bc0.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d342ceb8c22d3b156a81b4b060f13d2',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/4aa7b5aea39fd279579d155b918b30a9.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca87564340c565e07354458a3469d358',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/62fd0c848a9edfe901e643b7257afe37.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e34989d0ee438e5fc568a78be3c9344a',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/950c556f84ac6b468e3a3d84b02018fc.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f616ad6830cdbc4cc8acdad7da72e01e',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/f083c5dfe0e92295becbb49fd016a54b.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b269b58419358e4bc5d000f9913b60e',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/9b6295b6a6ff07dd41e8e777ccdf813d.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '642fdd618c40b241404e4029596fd02a',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/11455389dd1c22d8e349aec5d978ddf7.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edd838fe4845e815e10d615402080f56',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/6640a8feecb5b3002a1a771d75ed86d4.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cc58ab8f0400440ce234655e1cec2f3',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/ba270e6aa33143f286a2a38660d8f91a.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c71e78fd78527e7dcee0a98cbca8255',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/6e37b118a6cdf7218a07c10ea58fd43e.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '598d69718376a09586b0dc7c3f892905',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/62874c96ea513c0fecc5f8b8863031bc.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39c5a9fabe7586acf3249d7c829ba1d9',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/8d0938b0451342c882df65be59a29720.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f291fbeb45061592cf1d58f454bc6ca',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/b644581e6bb022109c136a956e3a5f73.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '81cc9ed8e8d22ab2c23b989cb8d2f1f9',
      'native_key' => 'discuss',
      'filename' => 'modMenu/8af1bc093113cb093b87f248e69d8155.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- Fix XSS in the search controller (date_start, date_end).
- Fix XSS in the page variable.
- Increase size of disPost.message field to mediumtext.
- Merge in various updates primarily related to search and solr.

Discuss 1.1.1, December 28, 2012
====================================
- #9350 Add missing javascript link for $lAB in default theme
- #9349 Fix errors in build

Discuss 1.1.0, December 24, 2012
====================================
- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl18/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4452202b9d61b375481abbc5ee3225b0',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/4e0e46c85a801d20fe240f8a3de752d4.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a54b133634458793adad904b9874a851',
      'native_key' => 1,
      'filename' => 'modCategory/e13173591adba9839e80f34d01fcdd77.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a5e2c2f6fe373328318f6912849c0bbc',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/b212f6a440813360ad348bdac7e53619.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a12bf91857fb8c3697851d41a39fda75',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/f6b3197f521e3da303f4c3f516f503c9.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3c2fc368ee78a8e1c9175f0c680b1f50',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/63c634393c0cababa5ff8d64a1d939be.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '64cb129e4e21eb7e9e1ffd83cd6aa097',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cefb74c28a5e059f0ba503904160f722.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '186f5857aef63cd8cd79086cda96eb90',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/15ad64d1b4d6eaced538a0fee2b15a67.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a1a778323be4abe509bf8cd40b9d509',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/f5553b1d2306a883209f5152ca7980cd.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '913bec84c7a1e5880f3850545912e0e1',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/6b24ad2ed016d8127c071f53977bf188.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '216519b0e66789517e4a1698201a63c9',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/3430a776b21a12f195c83ba601af1ffb.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '088e34197ece84882a8a524c9b48df60',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/59b4553fc3da860089a630c89b8d9f35.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68bbeddd6461673343e4fb6a2048f561',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/d380400b18957d712008dcd1d90e3559.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f31c1197868320485dd216ffb927ae39',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/ec4346d8ebf6baccf13cd6c8992eda3e.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c9da6e078aa3414e0eccc03b7aac861',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/141a96b64dd37360f66cc1df537676c6.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d59c9b9f898459379d31ff8a3478467',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/725836ade934746700286e7ea021767f.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e068f8523427a5b754060637286ed46',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/daaa4751d3fd1359e2783351380ca4d8.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c595577bfd8fe98bec43e7005f56eab',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/e11d7e564e9b2c8294b5d751ed86409f.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75d8d811697dec98664a51cefa2d9da7',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/7d5e43c7c3f43d47437c0e07747b797a.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9548aae8260183a090e2796ac0f77a4',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/75e72ffd0384d051bb1987fc84f15890.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bb89454259e814e2c8c2587e7cda28e',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/b74a874100bee7a192bdd0d07cf57bdf.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3457c5adf2d132f89d6dfae288af448b',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/3b80fa10b0aa2db0caa702d2e2804192.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aa7509b5b52b177791cf9706fb7345c',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/f50e948de8f83eda3df714795d7b1537.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09d3b6c71fbb72d779f100ebdc102418',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/d81672cb1169392c9be5fcddea65f232.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d2f8554578cbaf613e250beddfa61ac',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/5fbe884824b772ccdd20eb9a2000ea82.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77bdb10a26c6267acf827182994a0494',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/d5223b182c615347a59f56e3dd2e3e35.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2d407436018cda43e2a54b07b864231',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/ba5ee5c8c87bdf91e6d7f8f1980750c5.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d6a750105c8b8106c936303bb46c548',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/558bb0c5d10831eebd27b46fe3dddf30.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbe817399ad3d16fcf7591cea6fb5d11',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/b1a7ea91de6cd9ab67a1272e16938712.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b81af2400ebf2a319798e8ddd65a092',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/ad37ada51b34bae7ecbaf86fedfa60e8.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b667aeef71121c5e867a5c6cbb374c20',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/1c86077c31e750bc5535c69f020adbfa.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4630ceb76fb129d3e6da08b4bc45a0ed',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/7821b83a90750a1e6a562ba24bea4c28.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0408e04083ee08a4e8cf645a13c22924',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/f187e3b1db76dd5a9b4e098eb8d823ef.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63fb095d4e09ed7b1684d74732c09c20',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/c118cf36654533810718370438cfc818.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f589c5b0030568e5c504f71b8eae62d',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/8a05cda5ce8ac608c8c59a4acd67970b.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf9bf4ad9ab557a631d443b5cd94ed68',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/d5dae62badc516a0031dcf0bc3021a07.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd9c666197676653b92b9c7bc52cf2dd',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/74062a7c74942d40916e4d735caac800.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8e549e46a9037a5f85a881043fcc58f',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/4bec9542fe0e1cbc7724a23912d2595e.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46f96aef15e51c1e70cf17a82c5ba847',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/cc39d772f13a8b5466d8aabe7f295af6.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ff0df249b94d09a73df0e058a91a5d6',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/1a7c51c04970c3f90c12d9d3d4b86b66.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9bbd5262df1192318d48360b4a53ae4',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/9e6145ee93d41f6fca0fcc8b6cca78a6.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21f44b399c8c14521a69f4933a2d06c3',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/47978598babbad1d218a41f7b92ae107.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3f297d33a5f8e77e5254f8ea636db2c',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/218b9475ee2d2a785005cfa3c8cfe05a.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '405fb3d4c43dcea5701677261a4b64a3',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/fd98ffa8dd2986ef6a012a3c63925c9a.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '252c58f5503dd91a56d8848c5899719c',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/ad7667d26b98afd2014921db92cf6bbf.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cc8159b1c2f4a1f6e58b5c0155897bc',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/378f021b196bb5831f44eeed27101856.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77fb16c78ae30e042b3d72c68f4da99e',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/961b869fb61331560dc7de369616189f.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ac27240e79e1ae1e41c3614000c7d15',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/cb415a61387f32d852f1d8ad9300bad1.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8796965e02ce24c7ed9ee90fa3faf193',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/dfac563bd75317c00b7005b3fe21eefa.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30085077eabfbeb77ad22bbff8ce7258',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/b95b2cceeeb524f813c7f53a728e2a9f.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4f0559265ccfc59c75dd0f1585af443',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/5e3a51ee89fcc946066cf2b591c49c94.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9aa507c0363c101098c828e71766f201',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/6a773b068cf41776f071ee9f718858da.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ae6d9c43f58f268439b86e215939430',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/1b36b25b43b9b1686917ea84c185e87b.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c6480bf54900a71b13ba1cabe423854',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/b4d74be85884a2dff6bd4c4928cecd9f.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33ef266b87600a0f62c879e697483879',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/d383c9568e0e16b712880225c801e122.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20c05e32ffbadafe89a856bf08dda505',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/75a04183b01650c24c2410b0a37dd52c.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8509efcd1a02a70e89a2859f5a262a1f',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/8f8b7d6d6d48c45dbcc0abadb9da7951.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '367c5ee488043ea06840d544f21bf02a',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/a3021041f6e5dc15237b222ee16d9ee2.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5cfdbae02b320504c15065c7af6dfd1',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/128b42e72696174bd061c7556dcf9d10.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ddfe71acd6cffbcb8cec860a39c500d',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/4bcb774c8bae5efa730c88dfea7b41d8.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c212ededbb3151e391a961696f2d438c',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/ffd8ea98c7209d83d241512798c26c28.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f88329a1008be6dae01a98953840483e',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/8f86eec669c567b6627d73ac0300a14b.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee64ba0c2b37af948d374342543e82df',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/39c83ca58b5bf9d4bf54347f7f3bca01.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '354f47b0fe28739be4646d83dc1b4ae8',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/307142e3a9f349f34d00f551b050040b.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ff870f963a19e124c09148f06c37e2a',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/03cd2f384d8627cfab226e9cded3fd76.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ff47477744fab714501d7e54f42eb28',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/ad3c0f3f518a55b955bdbcc2a4b56ccd.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d9b64640528721ad164541533b309e4',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/e41978302c587c7c45b52f033ff88456.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d15fda0a975e72cc415618124149aca',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/61136520414d684b46ff2c0a1c5c76e6.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6cbb7668b968754d1e26eb519bc3f55',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/c020d52b135427ce9869b8b986cbf9b7.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70571a868e3b8ff92aeb48e99cea8922',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/2a036f2dddb8379203229235fa3ddb65.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '196f2c99346d9b3aa72a446b02ebfa95',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/f6e04095d493f0faed56f454b352b781.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07c31ab472fc5f3e71cd08424b7b8235',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/d5131b3a9a95071b94c1f20d4a458a53.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da40c70353e81918c62cfb7e0b32f373',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/8d6dfd2567f5deb3121052548d0ad59d.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67e8d04c0d6dcbea877982468ffab2cd',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/606c369b09a2cde21a8ea9f886c64a3f.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37d4a9045302db1e605771c57b210105',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/aeeb467fc4d2d01821221082e579828f.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6da1d63a85dd61dc8966885f76cf09de',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/50886dfa185bd1f041e423049fdf4705.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '665da10a6e715b1dac41e921b1a089c6',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/2a9f8a26225fe9d464b9e4ca8b035bad.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7285729e0286322d1dddb36b2d85c4bf',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/e7d3a0ccc9cf4c88b0eed585d6c1844d.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '393c6656a3d25f07169f39adf329791d',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/3ca11577c949db03cb656374cf8275dc.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28ecbb684fd83f3a10fa620297711fca',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/a5f9982b40a42bd649cbb1dbe2d9ff56.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44dda92c8d8b927d6a1e12fa0781f8b0',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/d9539e5f3b7034582a45b93581402acf.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0691b90a5009840d1285fb00fe13447d',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/36142f58f0aec2d4903c70643a71d8b8.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a4838db68d81cf826a6278e3aded189',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/26d1b80b835443dd9b0617f19d4f1811.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e962716d2009208fa86062b772ae255',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/a37bd4effe722b530b9c7702b1a51d3b.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef2538174fe4be40b697df28e430d289',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/27f07392f58742d63932991dce211ae3.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'fc47db5575b75fdeed660e9c7ffb98f6',
      'native_key' => NULL,
      'filename' => 'modUserGroup/20d9ca90aee4c8547fbfb501266c4aae.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'b7663ff381591f91389f1639afed9a7e',
      'native_key' => NULL,
      'filename' => 'modUserGroup/f3ec135a574704df49ce591fa34bb0bc.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e3bb96b3eaca444f4017b2251aac199',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/284431a9b0f4e3b1c00f62e2225b8cc3.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81649daa5f1bd70b1b7596d976746c03',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/f0aa30c62da78b4e8a4c1ece757b46c3.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6dea9abf71cbaac57aa61ab6e861fabb',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/1155b07e0fba4f9fb27d32bc0035154c.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f97873642ca5186f8c1bd28e2e6a75d',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/62e8c948734343236a9effbcaaaaa8ea.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c5b9818131e6aeeb159c8d7c0720824',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/a0ae1bb2e0c2cce826a4a227c5238207.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98276c1121e1a9841faff619db4abe77',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/2cbe2e349626b3407ed58ef4c3c59462.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ef223afd9132193bdaf5c5e79cdae12',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/de07a67b4a31bc42e0596652eac21523.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94df3a9fa9e2fd6bdf4f3dc369dfdb1c',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/0a4d33c7b247b60b8500b6bf26c5d08d.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc1615504500c4877dfff5202a858f92',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/51a226016dcd1f1de834a0829795fc58.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de428b5a159f5dac544e6da71efbf240',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/234dc63defb8b8bb43342674b5b2e1d8.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '486328df7e0366f2d4f1a26c06116484',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/f37c33e7df0fedb48dde0876fbee2fad.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de18d51b5b78035624cfb6921952e8f2',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/baad7f9526e46219dc9ef5f304215eaf.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c834f15662a049aeb885a2337ec7cde',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/02089dac7b40b4d03999dbeeb9eecb55.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2621dd65827e894998a248f2db0305da',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/c28d8e4137a9b8e43e936e076793d7b5.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fdabe8a8aecc5fae2373f088e296049',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/98baa8054935fc05ad7a2d6336825a02.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '684014af2483ad82dd64793237ac395b',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/285fe4d57a2766b01ab1652b23349968.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '458dc001afeea6cb4b8e1fc18edd60bf',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/f20aeb1576738306257358936ab7b0c7.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '21caad55a9b2eb65d64289f6f87354b3',
      'native_key' => 'discuss',
      'filename' => 'modMenu/4dfa12d7716e4f32145cbb3ec16d973c.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
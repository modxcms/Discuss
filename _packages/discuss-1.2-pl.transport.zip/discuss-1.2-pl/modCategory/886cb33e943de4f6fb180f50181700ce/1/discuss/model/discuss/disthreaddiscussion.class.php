<?php
/**
 * @package discuss
 */
/**
 * The default Thread type, which is a collection of posts in discussion format.
 *
 * {@inheritdoc}
 * 
 * @package discuss
 */
class disThreadDiscussion extends disThread {}
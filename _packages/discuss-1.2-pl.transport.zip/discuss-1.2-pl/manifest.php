<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- Add ability to bypass stripping remaining bbcode in disPost.getContent
- Fix viewing stats due to changed session place in earlier version.
- Improve performance of disSession GC
- Get rid of MODX.com analytics code in default theme.
- Fix XSS in the search controller (date_start, date_end).
- Fix XSS in the page variable.
- Increase size of disPost.message field to mediumtext.
- Merge in various updates primarily related to search and solr.

Discuss 1.1.1, December 28, 2012
====================================
- #9350 Add missing javascript link for $lAB in default theme
- #9349 Fix errors in build

Discuss 1.1.0, December 24, 2012
====================================
- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '435ffd96f2330ca5695652af5ad39df1',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/71b6fda88dfd496d93f0251c5d1045e1.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f7e922a8b18ffc916c822ebe3b5d18d3',
      'native_key' => 1,
      'filename' => 'modCategory/ac519bf43ec74254d534d8b4161fa3d3.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f618df0e8a7dfa550b81a8db86d723c7',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/86c8ad41aa38670f961214c66533e027.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd135c503141a873705d1f59314b95399',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/703320cd1393c3eda33a5b033f3d7b08.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2366b326d38b349f629b5658a31ad976',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/b6152bd3ac89ed9f9901aa3491f503ef.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '102a2239fb3725efd201ae5a0a439ec9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5d7e22bfecd73d05ddace62ecb1ad69c.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd449222b90be43957bb68798baf5db06',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/ee085f2b201afbb16429e0988d0437a1.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2825d235fd1f7b1d1e2690a47615f689',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/8b7108a9ff5fdfd5a2a1881e0896ff86.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ba6243f7b32595b7e31df7acd389c11',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/db9e2a2d693390b089117aee94a97b04.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7e4522ad938f5d7453357b62fbee0e3',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/9c15b28860f1f35cefc0f47348d0f742.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd2fc83af60f9ff85f1c8994bdbb794a',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/ebe36a80fd9a0af05d7e962fc10ebccf.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61477ff56ef79c3eccb5fd727d388cdc',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/79f61c77f6d9da2ec335947bd9ffa45f.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb97d6d41b80ec9f7c2454ce581dc80f',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/e687bb251fed644d1c82d6495117cf62.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53018b958520b2018aa90d2984f47c0c',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/5d874a64a520ef5be30027f33eb57d86.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da7777de6317590b8a65f6091a5a7eee',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/dc162731f63ad098dfd3352222e290e3.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eb88cf66fd545ebcb7111ba215cad43',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/37c34501f1dbd065f076a98da997281a.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74aa3027880b234722701506cf9027c2',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/cbd3239996835ca1af3e3c10776b3c04.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43bd89d30e87cf8e739372726a5e964d',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/eb5538a03bbe718caf86aae0c2b6e6a4.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e148eef3edd6815510b1649b870db2cc',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/2280c0eef9e57c9c862195babe0aaa49.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c990be6f1c66f2009f411aa8655846ff',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/4a95f8d0c60974c0c9e7416bb76b01d2.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0acfd2e2066669018948c1c39a654aa0',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/2dea294174bf7f22fc07d2f032977d1a.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a2919ea246be26a2534da21b688a9e9',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/20510545eef97092400371f4c2a155a8.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f40d90b59b8b63e4666e36c533be3269',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/deeb08a9774f68267739d2cb9de2283e.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9dd2cc1ce5daba7eddcc3ee6ab9ab81',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/a75e607b9fa7181837dffe92f7ea7f5c.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dba9f802d05e6fe31d40da2256674e70',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/cc7d7f613787973b4df2ab24929fd67b.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bef67c32735c6d4325375d6789233ad',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/1e6be872afebc109bfe9ff9617cd3883.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8165ca4783df8342a7c19fe37de96311',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/ea5a60ccbe2e6175dc895dff18d39846.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '735d31712b4084fd2aed16ec537588fb',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/57b765d3b133b2bf56d8f02c54306c07.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7d8f3364d43d07b7129228f6a58297b',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/5c509451f3cc08a8933b8903598ac4a7.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48ca10429165e2858f5ff7f53cdfe8cf',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/04e1e393b05bfffbab1ffbd2349f7075.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2de68d96c402f74752ac5fc8b170904e',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/d7fb6e732e384a28845f12f9f3e056f8.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2743cadd3b3054cca7143bc73f834aba',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/88147da320e0bda8557eccb18ddbabde.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '335c062e56a1c9d9ba90d3427b8e12d5',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/a2bb080f0c30626c18e9ccc0c6e4a63b.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9d2db185a6b2ef2fccdcc507993aab5',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/159c8e4590079490607ff22598433f6f.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16fdd0833eeb998c8827b989c0606a90',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/9b86ccab7f94a4c5358bfd62b91bc610.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6069d4290d4780d0e74aa536fab3fff0',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/ed2f6c0ceb1503d153f13c428096dd48.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '753d926adeb207214b030f064eb9422d',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/4798abf13436ed7524014b853e135931.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90237791e72c01692857c375b5c4ac7b',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/044fc1cbb5747d7d76f4c137b9e5185f.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2be3dc99a04395a02ce314065e6e9b6',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/8c7e35962f9a1cf06bfc6a5fa5461b53.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c69918cabc675fa05b0034eec78e46d6',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/812334649a0c0829a2dc85dfb44e3e81.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6aeb4bc58987b5a9198bec661f75cd5f',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/458e3b9bfdb64409368e099479d3f8e4.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdc8f7b87fe2f7687aa836f0722fd008',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/be1062a50c95d9e4fcdcc675ec4a968c.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39274485da9924d145bf626b878b0f0d',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/8ec441107ae35292b81150aaabc32779.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b1b22ebb4bed0d01be0ab7f3f5cb462',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/696a2b5ab5628e1a3b1019b95db035ab.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58d9f21efa65271aee66cbe22edca002',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/d7327e7879660bf562dfcb991f4a01c9.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a06a019a2c78b8e4535c1cdc71649116',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/84a7df0654d1c4c750ef5b4fcfc152ae.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63fa53ae19c21d1b637243a9981ab670',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/675821b52cc1cfc4b32e289129429e10.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1059702c2eb8c499eb00303a77ab525f',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/4ecb4e4950bd31cd112da02c5c64b683.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87394c5a609fca179f8af8f547c0f715',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/d4412df0346e92952afee5d60417efcf.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35f534c3a999debc7b05890d50fb22a7',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/77f3829fdbd525fc8059e3c11583ac8d.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c048c31f9c86ed37019d9b41841708f8',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/5427643bfd9c1325277eae50b215a3e5.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b3c6b7723a7eba5368f394fc8b6360d',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/a9ae2eee3aa548325a02a200207d024d.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9be466f38355a828a00de48e2cc0df91',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/63db6803787b44258ce060bde2b394a4.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46cf26152c4ddf803a34367798d7c0c5',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/b09ce6e1918aaebf6dea6dd8cf3bff90.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7cc62399285fd7d59cc58a6d15e5f89',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/5c19290c5f72d5d6e377815b142bbfbf.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb1d8c2de06139e6cc2d298f635132f9',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/152643028d08c2427bc4eb932c8bc344.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a10ccebdb10f45a934e098d71a57d200',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/95794d37451fca4708b933a9fe902d71.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85b133f5067b5a81eb33cb8381c9bfca',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/5bc3a3f9ed172231fbb03b38b15e8ce5.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61a8de9b0acd30466975cd0d85387ea2',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/8255cdc9a4653ff6ba62fab9dfc2323f.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cf598fc5b9948e9e6bde0a753dfd674',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/0c03f579a68bf2f81ce37b7b6b78c1a8.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fe1250b0f10770d81e3244f1c27575a',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/091d4e9e88aee28b562d80300e8bd77d.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b384f93d3d1624450194b7c213609a3',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/598a64bcd8095548eb1617b589713813.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40f8105b6f276e8f23ce723925d8988d',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/64106a9618aa385277c3fd24489136aa.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac6b6ab8f6fecfb666f57992a96b44a8',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/88b757194fd78da07467f6fd51a7e17f.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f67eff087899ee604c9ff9196a44d91',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/8b02eb55d1c31ad5fc2ef61ebcd1b06d.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '287425256a7c0e68179c3207a5ab3449',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/3803bdcdba575b28c1cfa48c48de3df4.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdc09669bc1800b779304be2d5606fc0',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/d31744c356109d85045a17c0aaee9c6d.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8766101ad6401f1159e7c83f51cfe73',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/3bbe6bfcae464542cfaa00d2a51c9fe9.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '243a03602c9c6b4ef98ff43f35d0a830',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/2b12b31ef5315904fb6d9efadeabd684.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c9d11a140093b161565414fd95c9f21',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/62a75750cb4294f0c3dac8eb386e4156.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '071ddffbe86e97d7b8c881946b14d31a',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/ceded1a9479e634537c05dca456c00d8.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d4478cb1f513292002fbc8d600e9d79',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/2c2e631b92ebfcd2c79dd85fa8bc3933.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b8bc589d2e89d46fe72c933ae4cc0f3',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/905308f329b72d199b7ba2abe21d0c07.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '984713353b7edb616fe9a06ce5889192',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/b5d8c2f5588230c507032b887e283cc5.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6aa06e738cd8dc4521def6d135616fe0',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/39529ee4a2b7c62e9eccf58e8229a980.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39683440f38921248f37246b1103e93b',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/cb7844c25ad1bbd6aebb00b124bb684d.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fac69a702c88e09a7ce6fe74753cfbc',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/b583ff63afc6215e2126a035180af954.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09ed77c5a165860d4d167d9eb65c5f60',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/93edb1356a1c470070c9139887f7af36.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e84d39da4a73389e5bebb76e5ae4f31',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/4d18e8a0c30c3d8bb9e325ce067954d5.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64f7fbaffb5c2053c057997eae1838dd',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/e680982c32678ed032cb4145c6f5e7ba.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '954a3ffb927b6f8fef0081ca9e72d1a1',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/002d492454dfa8654b23b1164626ac13.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ef9c6ab98a8d4b9aae3e7420ffaecf1',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/99891f2ed96a712a6365a5235e555b34.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4855ba4156cfea3d7487f18f2b79d0c',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/6067ab543464b406340eba1ec6e91396.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4b59b5bc1faeb8affc7e45ffb818e70',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/1cd98f8a350dbef9c66fcdf0145a7862.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '833a8631fe121f147a0cdb8627c8427a',
      'native_key' => 'discuss.session_ttl',
      'filename' => 'modSystemSetting/4be257f7856c3c13c4d8dbce55c10083.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '506fedc0d27e993706742f8571e7e857',
      'native_key' => 'discuss.strip_remaining_bbcode',
      'filename' => 'modSystemSetting/20ce2fbf2bf0599b30e29c8fafce7fa6.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f366a8bb92656e196f64824d8d299c58',
      'native_key' => 'discuss.group_by_thread',
      'filename' => 'modSystemSetting/52b6b82353517c9db3b1a795dc2cf13d.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f08141f3463688985396c5072903d5b',
      'native_key' => 'discuss.max_search_results',
      'filename' => 'modSystemSetting/73ee063e4f571ffd0699f2333f5d7d14.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d616063a214608df3d128d5f677879e',
      'native_key' => 'discuss.search_results_buffer',
      'filename' => 'modSystemSetting/82e73183abd4d76ddb00fd8d46d84ab8.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4006554dc0fdacf67f9a0693dd4f474d',
      'native_key' => 'discuss.sphinx.host_name',
      'filename' => 'modSystemSetting/6ff06c77128c54007cd6f33e14d7f910.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6a3611c6aea18bbd2ed272315421f53',
      'native_key' => 'discuss.sphinx.port',
      'filename' => 'modSystemSetting/b336245858459910fd5dd3ec0a25134b.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b79a8fd645f3396e90aacff4952cb5b6',
      'native_key' => 'discuss.sphinx.connection_timeout',
      'filename' => 'modSystemSetting/13dc34c929b5f96d8c7ae8298bad1454.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a001ecabe1eb4ce830909495d6ff29e',
      'native_key' => 'discuss.sphinx.searchd_retries',
      'filename' => 'modSystemSetting/3d20cff6922ea98368674fe9833d24a4.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '044607c996eaef58b0cab538b6395fef',
      'native_key' => 'discuss.sphinx.searchd_retry_delay',
      'filename' => 'modSystemSetting/709f676aa143f6f46b563411c6ed6e96.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7017fbd224238469aa805dd423b4cd05',
      'native_key' => 'discuss.sphinx.indexes',
      'filename' => 'modSystemSetting/6f70576442e316a3a3e7b55f84600e33.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '4401167779655d672e86db2c2f4ac88b',
      'native_key' => NULL,
      'filename' => 'modUserGroup/db0683d05dbc2628e6454bd52ff51c93.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '1757be646c1a44c590ff22b1e9238b6b',
      'native_key' => NULL,
      'filename' => 'modUserGroup/2bdc44484608c20bb16f7bd3fe28ec2d.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f007753233f881b6e759c7ac45ccc433',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/03576f3744e0cc22b5c8c8287f3db9ca.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3029c42e5eddec7d4e484bf790adc444',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/f9c854f0f0bfe4dbabb2799ac2d9c578.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8be9dc18b5462fbf764d8b76d505e1c',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/8ad6894ebf9c0c3f7acbb5fbcc5d8825.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74c66432a815e215ac93660c815297c2',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/e5d3531c732f5306ee51dc028d3a56bf.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6ae50eea7bcaca432b59c58b9b981e5',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/f9a1fdbd37a15a045b330950a7840471.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a7922482aa49ca618f66dbe2474837e',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/52099fc52124ea7ef0a615bf46bf603c.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96b0cc7943cd2d9afaa580a5542cfd2b',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/b133bddf8f357fba13915cee18a15479.vehicle',
      'namespace' => 'discuss',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '495023c1ef2686ecc5b4b560887a2453',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/0c54fb7936de3d4b318390cfe0c225a8.vehicle',
      'namespace' => 'discuss',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ae72eea3cf1292e371555cdda8a13cd',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/460e595ff4ca0aadd21cd4f35e2bd5c5.vehicle',
      'namespace' => 'discuss',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e011df532ae8a304d2d9d4d1cacf0928',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/5d39be9320f3ae8206725f4b2be57ef2.vehicle',
      'namespace' => 'discuss',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c07e15a2dbc41e0e3160b1ffdab7217e',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/319314a6efcadc88098b0eafb95446c9.vehicle',
      'namespace' => 'discuss',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a3c364928df28697b457ac51efff737',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/b5578de6d49e020fde55e04474d5518b.vehicle',
      'namespace' => 'discuss',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26d0a9f2d74200026f68496fa2df23f6',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/1ff70b2a0fb6a059f7687187969c8a3c.vehicle',
      'namespace' => 'discuss',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11740eba46283e86039dc217f700a7e1',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/2c57075651a6951a70cfa35f789ab238.vehicle',
      'namespace' => 'discuss',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '259f12fe122a00187e8306a573fd2a82',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/955f1449f3bbab345a6dcc4f4cc909b6.vehicle',
      'namespace' => 'discuss',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd445b588b293166279dc95f2daede7f',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/5edfcc6c6f76b1ab662c6ae705831fe7.vehicle',
      'namespace' => 'discuss',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32b4412bf1391bc077b47035a0c24792',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/3fec13e4793a68b488d9c622201dafd3.vehicle',
      'namespace' => 'discuss',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '31180e0c40bfdf49d2718ed0e6ac3852',
      'native_key' => 'discuss',
      'filename' => 'modMenu/83781684da1c4b8eebff2ff43fdf8fe3.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

Discuss 1.2, July 11, 2013
====================================
- Fix SQL Performance issues; new indexes and improved SQL queries
- New lexicon entries for default theme that had fixed English sentences
- Sphinx search server implemented for search
- #9525 Unread replies and unread posts are now accurate
- #9882 SQL Search improved and has fixes
- #9882 Private Message count refreshes correctly
- #9393 Marking all read should not cause server stalls anymore
- #9525 Partially related to 9882 and is also fixed

====================================

- Add ability to bypass stripping remaining bbcode in disPost.getContent
- Fix viewing stats due to changed session place in earlier version.
- Improve performance of disSession GC
- Get rid of MODX.com analytics code in default theme.
- Fix XSS in the search controller (date_start, date_end).
- Fix XSS in the page variable.
- Increase size of disPost.message field to mediumtext.
- Merge in various updates primarily related to search and solr.

Discuss 1.1.1, December 28, 2012
====================================
- #9350 Add missing javascript link for $lAB in default theme
- #9349 Fix errors in build

Discuss 1.1.0, December 24, 2012
====================================
- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e7691177180ab2167778258f29047d67',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/e978c0ce83c755b4adcecaeeacbe4d18.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8e0f5324515a24b553424bbe734d2b50',
      'native_key' => 1,
      'filename' => 'modCategory/886cb33e943de4f6fb180f50181700ce.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3de583ec87770a52fe0f119e773fe096',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/323d0daa694cbceca5757309dffafea9.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '572b98e771be69075128da8cff48c9a6',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/c444828bc9841389a779289716248623.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b24d803c0cc65241539058231648977e',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/7e0fdb7bfd027e06bd6478d3179faedf.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4545f15a0c4486e8da7666d9f139aee9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5cd19c29684f6a7fb3f7b1d9f658943f.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47ab9775e8ec3f17b78c6e3ee34ea623',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/014add728e4f1b1ebec672fd3cd7e0ad.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d8f4ab8defe4485e2bc94498c844a11',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/552705f2442255d9aed727ec5ddc41bc.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5a08e359280572a03ad5b88a799ee2e',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/19f92b1b81af3f07a7dc89b88ce918b4.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9844b46fa0075368995bc0ca974292d9',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/affd4844f1cda15275fd34195ae8ac04.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a40af5113a42b2b950f7fb12c4371f68',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/aae08b4a03e26a6bf4eda497f045a456.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6feec1df84fdd621a2cd580a53f776f4',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/589c964e4a2ea69776df104e8e94a109.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e359630425ea42f93493fed4cafc5545',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/51d56518463cc401d3fd30553dfe27bf.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16303d926d94a5e831e36a5c68d808f9',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/892a8e26f95934ef74ea588b66a46002.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ec90f6d9ec72545348d2e75a6b49b92',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/cb069308221117f5b36ba85c6b811bc1.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db3d8c2c798eb41d88fbd4c8c27c4015',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/888a121622ff38a6759c96af6c945ff3.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed09547319efa27c1e99fc94ac33c654',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/53f667169a6cdd26fca5aff57bc294ae.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '034fb22e897d18f180d2616c034f063e',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/eab67ffbeecfc964601bfb3d9618b05a.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '618960a03e66597fb28f4d455bf0b4cf',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/9f4522c4675d3ffc88d098cbb67c43ce.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f8a98579e158b9ecb42ca8af10adafa',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/199e7bcedf1ed7faf98e244b48d9b2e8.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2aff9696d0af8e31aad7bf2e2c35844',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/aa152ed6debcfe4319b368a4f6464772.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13c07d246c901b2a89ea1ad575d2a4fc',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/38461c867c42bc0758bc535e7250f0ae.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18780a9292916d48b3f680c9adfbc3c8',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/710ee21b6b9ac9d22d0e5d12d2b13823.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '804dae7f78caecc2ccad16932e84cbd2',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/1ae264bf1597fa949de7551a0f50a9b2.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f029f7016a5db8d9b6c406302f68d56',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/829cbf0df9134fa26bbe884ac052d452.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5c1c1749ad16a9c137b0dc8747e2dfc',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/bb7e109e26a0e2a9e5b19181fa276cae.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b92b3485ec297bc3fed2592cc0932740',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/200a6ce3666fb0cf3cacaf048cb1ebf4.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a0f83a9cabaf2d22a9b30d1bf60f0e7',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/1177ec973adcbd7d560a9e98fb3ad3d0.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0161528537a914b63db5c27ca6524d28',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/46afa91bca1a0125d9965cb3affa3118.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec980e3b8f3abbfb14764ad0d8ce0f33',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/bb0e8d8709256e04481a12b9c7cf1472.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1107b200f7277bc123516f45793ddbc',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/25e16109ccf34270474e1a04c30c9d5b.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b903055d09ab88e24306b2e9e3908edf',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/d43ad422626a2dc26b9de68576f4414f.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b2f4faab58d64eacf28692ca89defb6',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/6c5287f9930cdb1eac8a219e87b60483.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e74e263184076dc478f090b1fb90558c',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/4cbb2701512a5e0a86af94b1981bc465.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c56291b4d2bd99904f308eacaab580f',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/667c4d8bde966a1b9f3ecfefe85aefb5.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '689361f22c038452cd654f2bce1b03a5',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/b5a6fbdfda1702f131dccee9b8b97f03.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be77bddbb4c6f01e77ce4325b2c9b29f',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/4f6884707bebdcadda84af25db9e16bd.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '362daaad48057a04b8a9d14c3aa00b93',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/85d533f7bd67c540443ef5c4da82e8c5.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd25bd43014f3feea3fa4792ad179004d',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/c719e12eeb67c5b4a376462332096f2f.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a92201a93b22dc7cff85ca8c75f5aa3',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/58d780f2ac3cdcab7cfb15d21d1ca2c6.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b856ef001a2cd03729d877aa94a6b6ab',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/20d0e84a5c7550676fb5238556089bd5.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '480482592eafc5e7aae3cf3be010fbeb',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/78278bdf203fe2f6b39e10a89fa9424e.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f82c5ad3c145c482f2ee8b96d83405e0',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/2d44d839c836996e6a9e673a69c806b8.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0be348eed2eee3cee6116a3df70d2b40',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/cbc8efc4fea85fe8515064e409e74e50.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5180a90f0ac53ac3113e65a98ca7a90d',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/e8058edc0624076a60f8958193202b57.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dfbdb3361bee4a5077b553b6b968071',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/2e7559d9556c5bc7985447ee6372b795.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0d0a9d3723cbf162eae7f3d3afca1e5',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/880ab0e35248f943f3b3c98210e08da3.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a15658b0893fb386efe87b365037121f',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/60eb47e76fdab37add9672f026e6c207.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e1aa538b49ff16520575dca301bed49',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/f3a91a20031d499787127293ee677eb7.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de68e326e38c9362867d799765a139b7',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/e9d84eabf6a20f88eeb41257f56cb5f3.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f37634e478347352acd62fd4080d3f28',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/9f3decd84dcf0f4fcc0e8e2ec3288483.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1be03acb8c59611216fb4a1f5ce04265',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/342f3b59c991377d6740e4e6b1f727cf.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61360ca71c0e967a085bf523062a62eb',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/9f834da42c2d1851a1faf7c55ac634c0.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '747f8406a2f62917efa64e0f88bdfc16',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/5f5dd259263f818db5f2ddfea6197e29.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '340ea79b3ac16c9c26e3e2682c9d26bb',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/3f1c93e313e9f85fd34464c239822884.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f026ae20a3d91654cd2f45395332f531',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/fbcebd636edbf9ef5e2c6b2936123940.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7be6c0839437b9e81f9ccf442ffbe005',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/cb57b7a05f330106685bf0c1c1ad98d9.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80a8b36eafc6c6c8b0de0f036e8e24a2',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/fa683993635530f2d232bc72ae8a75db.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbeb62bb10dcc21aefb62153964fac0d',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/50511a510ceb52a7dbc8d21c5aef619b.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37e557df9ab32790eea45c63bd0e7d7c',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/fefc5fdfa7d11d1400fd7e2d5e90db2a.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a8c91ab5be90062d2273b614db55376',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/88852f22e05b5c9eb0c4dd79af4fa46e.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '215ac2dc45bd536bb348b0848281335f',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/9a5232f3a51b8947c91b5e674afd045c.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d9906dd1031fc552ff6aa9312567ec',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/4b774ae2cb93e47888b2eca8b45cdffc.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e6069d85ea5b58005bfbb1db4f99455',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/15301d255180f58b674a1e7fdf1ccf03.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dedf9df2ced27433c0638331c167d530',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/78d68575a6e7810f1b6b289f5a3628c9.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab2106ab69cff3c7cfd3c2e9dca3581e',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/a4912189cc9b513d5eeb578647f8b4f3.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3848d67289447976f2af1df8ed420f81',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/007bbeb165019fc8a3f60803def3bfa1.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fdb4c398d0c93a561758faacff102e4',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/639d85b0b71cadfd09c02e617dc42802.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b5975cd20841e2e632ed00e7801c79c',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/d35c9c59514571efe1d9d5622084f957.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1270ac4b6b9f1ab307d777399726f814',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/13b8ff63e1cd8f2563370c833a44dc12.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '322727e528c8f3f362c8f29b96b633cb',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/083d43f52988d52f99d7d16f464299b1.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08fbcc5c0d2841c672dd54a1a3d01b58',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/cdbddc966080672d785646b7f46afcb9.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c33c038d0dbe3f2386a6563f8e768f61',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/2c46ea44859b367615af5f5c4fdbd11e.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '535ac5ac27bfcda9856b4ad6b9e1ba10',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/45a3075ab6090789f31a108a08363c28.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b9164db9be11ce03c2da1162b82562f',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/2723bf8e23597cb0efdfd543db9f47fd.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f7f34aec6fbab69a07b6f1f59c685a9',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/2cbee40204c9d41078e208b29ea1d758.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b828d17aded938228d1e87d7d6b951d3',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/e8b2c9b0fd599a10f1b4e15dbf2200bf.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75c3c3ef971673ff24680a4541bb57a9',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/5b25d2742de2ae42df4c90011b61d77a.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d346fdf08761218305964a410361792',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/c9b0b9d1d44bd3b18f82d32769a1456c.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3536af0e8d51b5dda191d3dbbcc8dd81',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/52486f4b53c0c00b33116c1d0bda30d3.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22d827947aa03a59526cc3ac5aad52bd',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/c62d2bde46a776732f075829ff3080f9.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffb3afcc891060361ee800a84a2b2825',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/de0a4a53a775f313872242b32fd4e849.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eba1bc19fc1e5192635ce8eb9dcde24d',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/f2cab011a6aee6f09d5edd6feb7deb4f.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71d27e672296e81fb3c611064a1fdf1b',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/409c0f61684264f28c113236b24e94da.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e4deff917e8e295e433ddf740afc1ef',
      'native_key' => 'discuss.session_ttl',
      'filename' => 'modSystemSetting/fd80b911625e990b5deeb273cfb7423e.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef0c0722a2f1d341d90aa079bd80e3ed',
      'native_key' => 'discuss.strip_remaining_bbcode',
      'filename' => 'modSystemSetting/f85bb9694cd8890baf18dcb36b2f0085.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1e3f62414c485663b617bccb5a78b35',
      'native_key' => 'discuss.group_by_thread',
      'filename' => 'modSystemSetting/20574ba63d5fcd052e279b235cd142f1.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '752e73071c2f0d0a28fa7156a93196e4',
      'native_key' => 'discuss.max_search_results',
      'filename' => 'modSystemSetting/e6cadf52754299ec798e9aca385b03ef.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a963fdd33098b27df5313e9eaba1888d',
      'native_key' => 'discuss.search_results_buffer',
      'filename' => 'modSystemSetting/2f62ab2d518204cf9212dbe3b15975a5.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ae7f2a9de81ce0eac02e01a860a89a8',
      'native_key' => 'discuss.sphinx.host_name',
      'filename' => 'modSystemSetting/e17f21dd7272ee666420a0b8ebd92e9e.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5baa69280333779e12e89e7ab58e2857',
      'native_key' => 'discuss.sphinx.port',
      'filename' => 'modSystemSetting/4db19969dd87879a58549bd685acb5c1.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc925efe9237dd1d36d4352978dd11e5',
      'native_key' => 'discuss.sphinx.connection_timeout',
      'filename' => 'modSystemSetting/2928ad64df76389b6c418835f55f3e8c.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed9029cfc39840734081816b953d8133',
      'native_key' => 'discuss.sphinx.searchd_retries',
      'filename' => 'modSystemSetting/7a1e310431ec398247d73a78f7b85a97.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '402471837007206ae71585abdbd4b08c',
      'native_key' => 'discuss.sphinx.searchd_retry_delay',
      'filename' => 'modSystemSetting/bf7780bf9ad9d199fdefc18f02d6657e.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dcdbb7fa71e32cc82fb36d644dedd47',
      'native_key' => 'discuss.sphinx.indexes',
      'filename' => 'modSystemSetting/92792ee0aee097649ea555ac8eb3c86b.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '64c553d35d74e45aa7ea8f0bdb9aac04',
      'native_key' => NULL,
      'filename' => 'modUserGroup/ee97af23e6eac3d920bfec229af96a86.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '870095e03ccbed1fff0c143042f0d7ad',
      'native_key' => NULL,
      'filename' => 'modUserGroup/bb9089e91f74288ca507a7abfb160b97.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75aa7c88d3ec5246478ebc8e17d5f865',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/85948095e39956343c26a9ab8040d050.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0e350b04c641b9e102dbeff3461a8fe',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/7c5db4fc16e39b471b8567c67fd172a5.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c8099db9f61f8e1f8e56fdad3805db0',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/c5962938f4bc649e2523fc3a400682de.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6c9d1e2ea26ace0d0c639444cf5da25',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/d819bfcc273ccb7c60db44ec63692e91.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff143f886505e5a80821edfda380fbc5',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/6fd2735616fa5177ce252b35fbf45cbc.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40f86542f87dce36de80d2233994999f',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/55d9bc46abfe303aa1e0d68a981a9262.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36f33f07ba42edf73e748017877aac3d',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/6073fc063924b3c5e83d12e321bf41d8.vehicle',
      'namespace' => 'discuss',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '657c859c01d0b61bc54915208b795832',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/768f5d3cf94766592459031c3acb13fc.vehicle',
      'namespace' => 'discuss',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f50d1f35abc6e0091a29bba8a8382581',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/d3d91dc4ff8e253b97a9a8096a0c0675.vehicle',
      'namespace' => 'discuss',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94ab53605c10a9456da2cfa653d0a9c5',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/75e98d9997bfd30323c2a03ab52b5127.vehicle',
      'namespace' => 'discuss',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdb8ebba2c60b92763018df7ad7c937d',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/660120fedac5f7eb31a272e1fb98ca13.vehicle',
      'namespace' => 'discuss',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddb7a6b3064500f581bbc255f96d6c4c',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/f48e3aea564cbba4e147a7fbffd26049.vehicle',
      'namespace' => 'discuss',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d33d08addf95cbcd6d0ed7672a53237',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/9445288c9a1e2f3ad611970f93311069.vehicle',
      'namespace' => 'discuss',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c105f7aa250caaefe61278ad0f91c06',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/bc1321ae13a95346f375afae301e18ba.vehicle',
      'namespace' => 'discuss',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de86070c67bd3acf0bf26f02124ea51f',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/0de4825e367060d53cbb25ac2894d5eb.vehicle',
      'namespace' => 'discuss',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac33d928214e2ea58cbc2efdf68a0e64',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/4a31599d78abff601d51766abad711bd.vehicle',
      'namespace' => 'discuss',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de569eef540e2dcc570519085e55eaab',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/5555e228800071ef554e14757a5794d5.vehicle',
      'namespace' => 'discuss',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f9b4d9cb8e0cdda866589a06112d92ab',
      'native_key' => 'discuss',
      'filename' => 'modMenu/d0965df111faaa024bd2ad4484ec5ed8.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
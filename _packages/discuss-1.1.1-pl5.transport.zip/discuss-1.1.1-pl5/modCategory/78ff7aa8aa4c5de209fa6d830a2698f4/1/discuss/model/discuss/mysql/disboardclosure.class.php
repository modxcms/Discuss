<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disboardclosure.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disBoardClosure_mysql extends disBoardClosure {}
<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- Increase size of disPost.message field to mediumtext.
- Merge in various updates primarily related to search and solr.

Discuss 1.1.1, December 28, 2012
====================================
- #9350 Add missing javascript link for $lAB in default theme
- #9349 Fix errors in build

Discuss 1.1.0, December 24, 2012
====================================
- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl13/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ebe12405a5d494866e26dc20f806f40d',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/deda7ead8960f8d149c8367f099e745b.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cc3bea6e43f769a68e47e39a17810b93',
      'native_key' => 1,
      'filename' => 'modCategory/c9e395243c64b64a29a0651d6430fcd2.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '106c4f356b41bc2d19b66555171d9d76',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/e3a98927f52443380102bfc9771e904d.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fdc2d7176422bf320d675a3ff8530eda',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/659216bb88fb64ba78d455406a66c317.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '805deaefa5fb1d0b92c1941c01631fed',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/8cf08bd9816428b606d3a4323c73363b.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c6d70d75e8e65f6fd75f7e777430de10',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/be6713cbba0af47cf960768c6dcc1490.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '668022e6a6f2683c58aed77e402b06c8',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/551a83462b62b9e761cd9018373e99fe.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '329e23b05fd86df27b57f975ff7a675e',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/6ba5ab44ecd83ce017a56588740f989f.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '408dc2a30e123849019126edecd2a723',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/79e582517b9c402e06ad139b8ad581a3.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17b65ac995adcba577103927f5dc18a4',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/f652a54e09b25707998d52109397403b.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87e38da7d34a9af097d7309010d4b2e1',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/ce007a8d8537c9dcf4c9337cc6e46882.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55a41e724315f4e8b894d5e8160eb1dc',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/32e9999976a003ecb92daee2d03f66ab.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b6627a8511655dec06060a6e5abf2ed',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/388289e37d4f8a76b15ade31e6890302.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00ab2aa7f0c8982e2c12e82cff754a05',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/f639f5aa8895d53cabb88f7b299f327f.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30ffb4557a930384c697ea79bddc160b',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/434600ac61ba6be30f47251ae78be975.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8582a7884314c3d6c01c2434641969c6',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/2ee27b57d6fe868e7124498fa19c6adc.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd02490d7a2e0765d30c54c79bfd22a61',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/d01081ca85b87213f380d50e2a305639.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdb8d844a178c77b70e0a92351d4da66',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/747c5a269a6f96a0644afed8381704c7.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '559f31f4c59932894785a38b971ef85d',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/974e1de82473a27731cd63b69bfdfd91.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f8027d7bf6c076b29a0db113f5ff5b0',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/e1c0a81f20752903783d30f522357763.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2e086fba015f9c6e5fde17f361405d5',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/d13f13d7028452ca879ba20376201f0a.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49702dd0b6c600f26dc8501242dc7c94',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/6535056c17fa0c76ffed173e53d6e90d.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '114e5a110a1e2d3e3dce671f33533f8f',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/bd3fc31933c391998be43870b9b9c0b2.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9e795a5873e459d3495d7a6dcdc0098',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/50f4e4abb7d7b0a4607816fe9a5815b0.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77d69d507876e980f578c0007a7a7aff',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/695490f8b8b3a94d94060677b37829d8.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04882088b98ea8432e9404273a3fc563',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/49a2ea6aae3eb18acc851f1d86143e57.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b64c6ddc2ccbf3f346dc3252770d85d0',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/802cd39c15946175b317b55a3afc6c54.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaa9cca1e78fc2fd60808b36d472b5df',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/fdb07753af59b0cc8328d40eb3bd0e30.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c43666904e1f9a5a8a202076aeea4481',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/89fe93f15f3c69f17e9b112385447cfe.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04c1bbc8aeef1eb7411708dad41385db',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/6e0809870d82a01cdc76a7e66efa3856.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6432f81d97e263e5fb07f3fc31ff09cb',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/602ba98b60a75834ed1d889e5e6810ca.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '343dc9aa0ae75a37e77d7ad3ec6caff3',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/addff0eae5e96db0ddf8fc3c2a9fc451.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4af99ea43f531bf78dbed04d5079ea88',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/329ed1bc1b659f5bd42ecbbef08c4a0a.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7291aec41461e37957a074d71fd2a493',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/a14acb28affa1615b206cc5d2ad89c2f.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30e26605f6ac6e6037677c9469311d94',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/55be128d8e13e6b27d0b9fbaca82ba57.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d49065d08392846eb16aea9f4c7ce01',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/d15add9cfecbdb68bdb924dbcb78544f.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18138bcbb03f508a0fddc57dcbae5877',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/734333aa23dc8f7a39df8cdcdd404abb.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f74cad844d07697854b8956bf424ebb7',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/d635e9fb54e53c3af864e9f969057ec6.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd804f66c4f1003390e4d5ad21c8ea2c4',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/db69e18647f4fe493e6454deaf1b49be.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7add42f65394cd9c9c4d493c5be5f9b6',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/e22d74426d5cbd0dcf9ca557d010ac81.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffa78c1fc606e98dd5c52536918d7919',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/de8255e83f5ff78d7e0d900e379f9b9a.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd57bb0d402ad3364a5d808c58851fb70',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/46efebf88355e80909aa1dbdf112e3c5.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e24798b181cdb02803745e4dce434b6f',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/4651ee7a812a9bb1786dc75e704ad032.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '599ac6b34e23b4a1a755ffbf3b05cf43',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/9deb700fd23d5a9cacacf9a4fb134ecd.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ae94c69003db3a2df143518f4d625b0',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/792220f7bc5b55cdc98e63429bc2ca01.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12fcd0d2c70e607b80de1eeb3016a7ea',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/37f81d12e3d03d38ebe200c55ba928ca.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76637b9b98a8695ab314206b2cc820fb',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/93e89b9677d2057f8a9161c92d02bbbf.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c426f48097e98c60a88c711fb581906',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/8ab42139bb019b5360cbd2fa78cf8e35.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d9b016dbab8d5f1717d23da53daa555',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/a2e66708a1b61ab2c2e04bdd669a8379.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e275a9a06732fc32239487ecaa5279b',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/6fbc4fea9d83555b6f0fc98ed469dc80.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7823b97ecbf5d149dab6cbb4cc8f925d',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/0cc905f9e8557888fc67d35a306db6a6.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '154d693218761b3f91a17376222d51ed',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/61479b9dee073141e92bc92028ae7298.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93b3c50ffce706cce82054ad487ddfc8',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/7d828a45afc9feaeadf8f010b457e29e.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8b6dc14ea4f78669107c32838e314cb',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/721c4e08f8fd765276c45b89c25615b9.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dc06eb6aaa59fc214b3b9508f6baa1b',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/833b605fe20571f5661ec093a3722628.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '135b467ee6f5a5f5f2a5ddc51e7ff13b',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/7830b5d8e50799110d93dded529689cd.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b99f65f536c1f11fc22b7ba28f55084',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/785c7c4a45c417a44812c2d78eac986e.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f3f3d8cb82331e67d1493cefe3a1982',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/9729f654c6ebf35fa925412f4e08a54c.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dbc6934c41e80ace4e78bf63cec96ab',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/10c0dab9001025c5f49b85b1f3b23218.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de3b856259288d78708d899784ed4615',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/4c002b8d143b053f50d3b4eef8452d45.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95efe79bd6d15d729bf7d75e40581dd5',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/1ca9e253e56f1c27fa104024e9027d15.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '632759d692bd2ddde5e2e95561bfb3ed',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/f05fbd5ca76812afeaae59ec29a0e961.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ae5f039b93d674c9d89f984d7836218',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/734f0f308f7a5eb35b846700725c6d6a.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0e2c5bca8d8fedb8faab45fa12a03ae',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/8eb41094fb976d0fd8c237bb45ef22d4.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e1170641760da9671de1c9d41f7ee86',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/a12ec37d9208e1516717b7bfcb9adea7.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cf599004f402b762e438ffc2595e59a',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/1a9db7e9725b656946efcf8457c31f1a.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39ec20069e87e6dcde7661df12732558',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/89a3d36c42d0c7abc971cf67707dfa86.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e3941bb792fc74a7256ef9753a5f42d',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/2801e3e5d794524b3c32f9de9d99b59d.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd84db06ebc918e693429798a268d257e',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/d04d3caaf6ebe903f415a32898c89012.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34668a475629e3a9c8f497d902ab7937',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/c2055b04c3b2651dffca99975c2c8ce5.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59096224c3b8519ff8e2492181545899',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/b95bafb3143865d76e5c69711268086d.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d9291ad113852d8734f419ea071c873',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/f127e37b9a6031bd7e901cfcbe745e5e.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '046d13d4adeb0d7cd898f7f5adcce7d3',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/64f00a127ea8ef46dc90764fe906a98d.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40ffae0161b97e07a64a4b8b414d0bf7',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/148c612e05b9a37eaf399dba4131d501.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a21ebae033f839de9fa83073fcf5798',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/17d05d75be768a90742fd688e1152c2f.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '227eb37704b51fea40326bcd99370dc9',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/4e6c3e7178bcd3a44cd15e001212ca55.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50d77c99190a1ed54136c285affdb1e2',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/c9ff13cce7a8c6af03932c06e6f96171.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3104b78e742715b5fa32e74a454418be',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/4a6a4ff8e51dbb6308858fe5298c7270.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3637c141323cebb858c3e1c72244467e',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/c07a590238f4a194001e519c4667fed7.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '326fc79d0733b81071db541fc1aab381',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/f195b835cdd853e3ce2912d7168a549d.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e501ebf1a13587b59f0f535a091ae351',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/2cfcd86bd26fb489930d15f46688e848.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd60c3fe3784c0cd425c2827e22b65147',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/ab93550b40559975a1eb84c6253b5b10.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bf0c3e1914db1a60894afc711d6c4a1',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/1f5fcc9b1533a69573b876e263b5a93f.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61a69eba99edada2277805cdcf5762a4',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/41f6d40a85a8bb9261fd5b8805593da5.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '0c7b453df612ce56a1a05c9721108dc7',
      'native_key' => NULL,
      'filename' => 'modUserGroup/5ef1b2742ae108e3d9bb34922404622f.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '1841eab4ba38c6b76e2cf18162355f3d',
      'native_key' => NULL,
      'filename' => 'modUserGroup/f60e002a6b8c78042c3399b3b680a021.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4fc0af32cc21dff5df0293c925675ff',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/6473c8827d6555fce021f8eb5f03a988.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '274f9b6bd758662e9816e515962d7121',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/ec42e996b50bfcd97f80a3609914c666.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '864027df31055597c6036f3ef96d266e',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/310e34b0d2b9be11d830d78e0164fc44.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78636da4ba4991d0924a267ce846746f',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/463bb03ce6683e8640fb03951ae6793e.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aaaf4176d3b5fb5f30f7e4cc6f94deef',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/a1a7e472d76e3591c37fc31173e12d1a.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50cbee59fc5d9bf85ea883702a679c11',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/3bf7ae36ac082eb23e93f6ff1cd80e98.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6576347b72c802525389b88379145fc3',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/b46e367e507ee9873986da51920e9246.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22137aca02e4e06018c10f3763e2b8da',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/ddebc3d050abda6abf752d8e323a32c1.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a361b02dfc86d6c24af5ecc59528eb6b',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/2f33cbf0577474dcc45b603ce066aad5.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37e946aa553c55530296fc45b96f6ad3',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/2502f5436e2de61dae4ee25a9bef0228.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ca3ddc5582421c8c401cb73ca62a73e',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/99b0348e4aee352d072849e03a926bcb.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e396d1af54c97264269b293757d72763',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/a4a661befe840ca14f4e4090f4714778.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84d004fc18ac4a8172c327618b4de04e',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/bb935410a1de05cc57969df1702ce02b.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '019153e65b3d2aabec3dbc1e9b456b44',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/81a7cb4220b35900633dd0df67766bc5.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bb251702c5b365a2637488b3e0d05c8',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/927520e768bd7f11c62445f1c4ba476a.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69cf1dbe7756ff792d2beeef67575afe',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/cf6448a6a0a0968c60fcac0b6c5dae1d.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afc067fca13c9e73a905406c5f8a381f',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/eedd0e5e3480ad8277dbd78c92e8fd93.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e6103a40c0c3a6d20b6b2376696d272b',
      'native_key' => 'discuss',
      'filename' => 'modMenu/27942524b4313465a1e5ee1236579e57.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
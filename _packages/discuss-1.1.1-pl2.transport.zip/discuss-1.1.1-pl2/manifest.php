<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl2/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '46ce3afb02160b5fcd4244a02f1f1a68',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/5b372e87c9e09cb74ca34d5328d45c64.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd795cb1d931e2d58189c9397a4d46656',
      'native_key' => 1,
      'filename' => 'modCategory/d315bd660b88efd07f21c6a58a76ee6d.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0974ac9af9be55de2d1696284b6222f1',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/7c052d76123774d4b8ef08ba70643574.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6a83d0e7e1f5a5d394266f88db6aa628',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/61679d852645b648a4ffb54761c0d5ea.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '012c0c138f148577b6f352717c125fc7',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/fc899fb0af7e2e83e633e02af85acfc3.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '69d5e8c0bcca8b66ed82ee66006310f5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/32645adc6889a41f5e274562bfb823ff.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f10d47b7addffb6ec9c284f9163eee39',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/c525090d5cc3d30e6250d879b7474372.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3ac1e89c50fd60dd317608b5380105f',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/01cbad94107bdcfed2db5231ece38310.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb0707667b56fb0ba588ababbb67d2c5',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/4ed220b775283955425cf93cff56af39.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fbc5b87380a2170f87eaa9f00817049',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/054bd0643645d08182824c8a0cab6627.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '225563f41f93008dc081b89e41d5835b',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/79b7ac5456eab51b608264432a92071a.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbca82223c0ae2c8ec154acf575fe57c',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/b40787012317b9c52f644691a4bd8242.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba877fcaa9d4325684d07f643b90b3b5',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/8b2a1c027d55428d7e9cf88be3956099.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82d9eece5615dfb2191f309304b2bde1',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/4fdd2330bc91d577c9f104a4b22eb248.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c6bd7bfe271b424d21f07831717cf33',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/e6106b82779d410cc464ebcabdce549b.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '685c1d8fe0922c134f955a4ef3c4ed2f',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/42ab7a34c04ce5ba54dc67159a1419f9.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69e20b8d7ac060d106c8fdd80ccebed8',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/d5328512a0872d29dc31c3de62d6b918.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd87ab40bcdad5dc566ccddcec7130efa',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/d1434b1ab55bb2361cac697bf6b20b39.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a17292faf78b2be7bc2a69b2d7bb8c77',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/216b55f2d804b05426a0473aa35ed7e6.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4d2d1c8cdfa1a644b50eef166005cfc',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/85b8d84b9811d3dc87985994970d27f5.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f04dd6e53e93e1ba0f78930dd225ca20',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/4f48acf1709d5626f95efe2bf9f407f0.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '748e0e51430d5fa6cfeab5a3a738d8e0',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/955862480966a7702d4ec46e1c673aab.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '302df424a77de5476e72e5bbc5f2e730',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/17075bd90cce8de0538e14f43520505f.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bd2ccccecffc0e24d02d78cf046c194',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/8633bd649df4026c7164ea0b2a67a542.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e69f46c0470104816c006b76994aaf3',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/f9a8faa5a93c790ad12b98e8dbdbf433.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '497c1bb8b76779658db49489b1237f05',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/0c491e56079a29f1108d9045ad1b4359.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0075f06a2904d8f673db59d186ee331d',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/080de8a458f68ea49a8ad422faafaccf.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '266a99dec869b989c8a2fa4312e374ee',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/c57c8c262e49c72b0d469273b1e6b218.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3625d4a880d38ca72686cccb092d691',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/eccc4cb0bd5b3be884754087f97483ca.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de3157713b12e902eae3da2f5f17919a',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/7c87f291e117b9eaacb687b652d4a05a.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f067e8b1e9acccb9c9586df93cc27f8',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/521644b9e931bd40f8ec8e7071c74552.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2bdfafe0de2a41134b4efcf7ef293ad',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/3decdd10e42169f2d427883ed98c3668.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '371cc5067615e22bc5fd807b453c9f48',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/ff8a914d14f0c404138f72bb107a358e.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e070a96fd2624192d1804729f87a5b0f',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/213ebbbdd9a3e14e450eabf5e9c18872.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2059a7ea848eb66141a26d258e803a95',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/41f734069460818920c1668049c4f448.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a5c0e6672a9af3b9997e28981a0859c',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/fc387237c8bb1c5e499755cbdef717f6.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '170c464d276eb4cffffedbd1c76c3fc4',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/45c78f711391caf11b721bee2210fc90.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9f623759fc4cd371185e38bc0c345cb',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/2c7d0d68f66ceac114accaee4dcaa8d2.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6e7a28c04bc67eb0e7621187242c6fb',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/fd798062a51b250dfdcb56ee4c5c6571.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58c7a52726e3a3581370e21aae2855e6',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/bd52eb116136801903ac7e532b8c2378.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24f25f91818db81e18176feca32d10d1',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/68dbc073f6899aeda992af1634dc10ab.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da83be23179ab73eafb6009a059d1487',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/42e4b03eba21522c457b861fb821c609.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a61ff2e15f192a883fe629452f3998d',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/eba90d84d33e48a3ab7f9ef225a4c6b6.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9a5491f68f02999fa86ec4525b52832',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/2934f3e3dd7af7c627c1b4ac32ffadb0.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0cdeb851948671e67198391a06cae04',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/ff4d897c88cc29b169a117893e0fc6f9.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '812b2d902f81effa2eceb7bc86157d0d',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/4b77d0654a7415bed08d7704af7546d6.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c14d432831a9b90b1040da0f569bc0f4',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/9142475db30e5b5feb6ed8303270cbc2.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3baaa4e457637728a8d44ab359b12c15',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/b4a8de4a529b2f8acc6d49d11fa776d2.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d6ad0aa15700b4ec7035d11d141a324',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/3554949266a16ac4d1c092e57445dae8.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a20e53e44211131c4f1300b68ee77189',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/1fab5ae8e991d61ab371d97a11cc7a8f.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '069fc7570eb96985d96873813ad2faba',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/8c40793e5c61769a7b3134367e87f4f3.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5607db53f9e5cbd7cd0e27be3abf59b',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/a6daa7048c1ae1dcb3ee04910d835c90.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7374f03e868705fe74be4f52cd4055a8',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/5193fb963d89b783ce2f45a50d615ee7.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5da6829185ba96b77389dc9ef02acb3',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/8184a41f9bce826cbd9749791ca6b9ef.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a92c9517a67c323f6dab7df2b59e02fb',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/9031f667fcf7501ec17da36067dec59a.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b11a00aeee389cb236098db00eabd8e',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/70c0bea1f2d7fa22324aa197cf5ab2a3.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af263d6661af5c8b2202ad7a95879ecd',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/83934e2559a28dd513f6ac3529f9dc1f.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '431ea0aefd0ad7aebbd5cc7802d051dc',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/ac32ae8d483281c5313f7d28497ac196.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33fc99f58697348167fe9da223eb8944',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/daf67e349b9bd8c93d6dc7f43134f0d6.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aadaa2d8e480d977028029e2ad489b81',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/062556bbaae897b9acba2c94576c2d70.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32e592da753ca77e339d5f9d4443ddef',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/c54ecfa87795a6f44205355f116cae70.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97c759d0768fa41c4fd6b08d41ba98ca',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/c2a15d4f1bb609e3a9004c93246b2bff.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4850877c896d47584a00f10625b03c8',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/fba8ffbcdff9f9713d303533ac475c8d.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '266f7fa3449d0c5e5dcecad5ebd10922',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/03df54cb7f09d76ccd15b6ba6da5fde8.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4804f4481b9d433cf5bb1fc97e52ce5',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/1becf4deb5d6a0f5c8d047ce5b307a05.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc8114393dde6d71e9be219fac1d1d43',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/7600a1555a9917a4a6287c118746a88d.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0e7121f7915eab38e61ae43f99ef7b2',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/7f8e02e1f4eb51252ef3f9ae6138b3dd.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad89da532053f88196fb3f882f82670c',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/9c477b8bebca712d957121ab094998ef.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f7ce7509f2b372d685cf5ae319caf4',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/eb112f5e2ca90b33a17747d4d7ef0b53.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a2a17ea043447f1d4a8c208ece0a8ff',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/fe49b6fe67c592ff0d4ff2a53242c99f.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a39281257b5ea0a43877ea54bfa05929',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/954ca8d543b6d882c630a8bcdde83cf1.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64b8df25a27392d244714ce7c9de8f92',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/574e0aadc087fe718f83766e2f7b8416.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9547945a4e45a34a73e93c333ca442c',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/e8bb3d1b5778a876f1e9a5bf3ddff5ea.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd9e7f3f285f280007e94094d51725cc',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/2134570b1a68c278db1eebf80fdc45fa.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd67a11db38dd13e067bd0f9da8fa4b6b',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/5b4a956faf2de1df94b983bf1b88a47e.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17e38643415bab3e54483c5b144f5fd9',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/c9e97cca5c28e8a5bf9e7935fc85e275.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bce0ac9bcc79134303600fe2ca3e0ba4',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/f318823211ca6ddd98f47aea1386647c.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba41d2340d5d829c6de7e94a817565ec',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/14bb57c75a48d25faf73e40932842079.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60b24e4f0498be0e21c487fe2f4244cf',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/fd667bd20df0aa34e297cacba0e6a318.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15b578de02a1921958e4ab37f0669291',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/ae6c560994cc26f6e29b250105f43b41.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97b668baf3be3063c7ab58715b2ec11f',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/730604c39b078fd1ddcc82a2e1006356.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0703706dcd63e316db30091360b8e292',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/2d3b0b0c969b940dec75f80129d3edbe.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '233c7a18627b251a12404e97db15c819',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/f2889d93a0c2ae2e6bc7fa05a5161aac.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4764606e53bdf0ee5bfe059ca2365f86',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/3d5f16f853690f5890f2a956566a406b.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '36f24e28cd422e42dcc1af63170cdebe',
      'native_key' => NULL,
      'filename' => 'modUserGroup/fca143f5a9c3beffddfc48b66c408fe9.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'd0f39532c6e98771367304e90d92a356',
      'native_key' => NULL,
      'filename' => 'modUserGroup/969ae4cc0a704a6e50cdb4d692afb0c7.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10d26ad6c6d20403d5bfdc4ead7c38ec',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/a760c31235240d8712c235a050cd2cda.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e84150287fecebf9e644f25d60df2ae',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/bd56e12dd9040b96bab357966091629c.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2eb0cc4b59fcfde1eea648034daebed0',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/9ad1756547ea34d6dcf46677e55f5abd.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b8de462eeb84387f24534e542f9b8df',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/42cd3b19c75b5aa6b100f94c5e0ab547.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05b6a350929510b74855be0c3aae70bc',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/39b9f0127a9a6980b6fead6daa652783.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c148cec2c8bea8d78baa5f81e2dd760',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/bf365cd5bd540c8790243ee7ac9ca4ca.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71f037afc4ed40dad953f1c0b58d50c2',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/b1d93384e315ca00c4fb76f65d940a28.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4fd3779ce03c4ce8838d0024e7de916',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/6e529067ac562b1ac8004d049b4c8f9f.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bb776cafdbd7e749505c9a20f77fd63',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/dc2a411e2c1904917810d6cac326703f.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16a89b0fc89b2233c493ee39b73e99ea',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/8d27ad64ff049b05ceea294a2a2945ec.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f7a67fa82d09bde7ee7c6d9b9486ed4',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/8031f4e9f5613009a4a39fd5c52a500c.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3411ac2a99d463440bb93a8e75149a36',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/df8bed95602561f9a2030a13aa896a47.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e5bbd42c024917af53191a35bc54dda',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/660fc5c953daa1d1ef4a635fb4604d4d.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4016b59cd40d1433b09488149d9a615b',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/b4adf8c83a21c5cb19200d14c8dc7457.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8dec8b1a0c47734eb3464fed4c3dd113',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/9f83b5dcd2c4bdf6746bbdc53b9d76a8.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f93f342590c553423f79483882738c0a',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/f5f5232fdb20ee8253556165f21f6c5a.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9896123e037d66187b8bbc4578a20cec',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/8c0fc409e3a6a4a2b88e3bbae37f97c4.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a78251f790619336ae0eabee150e1a46',
      'native_key' => 'discuss',
      'filename' => 'modMenu/c24834720123beb9a1b986735432be60.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
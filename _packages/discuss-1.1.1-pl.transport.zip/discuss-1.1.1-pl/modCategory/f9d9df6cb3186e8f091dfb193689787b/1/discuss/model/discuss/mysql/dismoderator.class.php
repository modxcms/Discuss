<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/dismoderator.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disModerator_mysql extends disModerator {}
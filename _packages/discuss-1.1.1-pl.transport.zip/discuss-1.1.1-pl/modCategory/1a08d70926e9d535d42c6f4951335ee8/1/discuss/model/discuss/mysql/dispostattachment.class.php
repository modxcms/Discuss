<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/dispostattachment.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disPostAttachment_mysql extends disPostAttachment {}
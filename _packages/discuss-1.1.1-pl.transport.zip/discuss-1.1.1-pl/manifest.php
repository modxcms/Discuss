<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

Discuss 1.1.1, December 28, 2012
====================================
- #9350 Add missing javascript link for $lAB in default theme
- #9349 Fix errors in build

Discuss 1.1.0, December 24, 2012
====================================
- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2a96132fbe5ef015fc75bf04e2de1aad',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/2be64447a38fb8532dd4c2aa52109ff8.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'df2aab961b932000ecab3ce45d907293',
      'native_key' => 1,
      'filename' => 'modCategory/1a08d70926e9d535d42c6f4951335ee8.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '983a12f8e9653b52e1cd6e567abe2c7f',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/7924d69e8a9372b1d8e8ced60f35e882.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1824d76fce4cfd1b7b098a3b488c2d73',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/e98772e85c863f47ebc8c1fe08b17b77.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c757de7f4290c8db1731b7d13228ee07',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/2c6f1092b9467c273007a3a7cb5ba2ea.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd5dfee2f0b9b373ac748e5a899b961e4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d3dc95b2cc8824dd56a3199a474f2f63.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c1419420c07200c199005fae6dc51cc',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/af0e3b7e10720687066072d014acfed5.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ff3f9c037437234de87ac559e992d22',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/115c147008be6d55abcff80586ab2f95.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbffe70548c9c43c0e751430defec82a',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/bc5a3fc19a30a0a8a7bb48f474ed3f92.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d374d72fa0ecf7b0b19c25bc241415e',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/6e35e3715357d39e7e53466d7e8c7f95.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41c7621707dd4d229c528df92e74cd92',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/e3d6dca321bfa4ba86e39d8eb7cd019e.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd82475d4b83a16ecbc8f6cc79488b0a5',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/8abe119a9c36bd2022b4b6adf2c71703.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a188ab81ff6e6f99f2a55975f008bffc',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/08c98cf561006325347da5ea0b3c2823.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a2de770d71549891836d9d3675e990',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/c23e4d0dd56150ac0150fb65c50edbcf.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41fdd1d1d076ed478d13384c38386271',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/d2068a41d0b800f6223ca664ebb90f5d.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9a23905bb383e274a1a695c40ac6e5d',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/8e75e372e919625736fe56c144056234.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3300ac785aaa16acb523239f515d604',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/70fd1821242d4ceffb1e760271202ba2.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02ce057ba22d604a1d57b4c0a9f5d25d',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/e9c38aa71ccaf273e10bc0546cc513e7.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12d8aaca48927cec31f0c5fab36b84f3',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/c1b8e345b777dd02c08b0a920da375f4.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c7ebade1b4005ec8be19ae0a776bcc2',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/63e9b6eab2f994024a8975f754772719.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '698cc7e109687c57919c058979bff2dc',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/29ee859763b353df6d4daf6acefd06d1.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b7a9f36c2574f35b51ef4bb32fffe22',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/391b17871c22afc084c9ced229a61176.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77439616c0220167a16f65b74bf5b092',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/d094d2847815bd459145d3efd976a026.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '069b15bb2897599153f1e9f627afd537',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/662761dd55fb53afec077076166e0def.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4707920b6c7bef4d0f1eb074083e7194',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/e18779b596796669cd853c716424756c.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9d4d7183d0dae30fbe8cd0f9ef6ed0c',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/a6d612430f99c6778a3a85323d5cb313.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db15dcff1ede62e4e6ec4145629875d5',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/099e8922e88f5f38f3456b042681d529.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f776557eea37e2589cfecc47cbb48aaa',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/41c0e01980e8de193afd0174acf9dc5e.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9544828ed5907ee51498b74d1ba71dc3',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/ff522d29fbd7fa16cb056b7d052cffb7.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6efaf8ea775e14cdc4d30c3a8308143',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/1ad722cf8447ac9da1ff32b8ac6a3bf6.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0495798f53a9ae7ddab8f1f644efc954',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/a67fa314ffc006867f7924b3bab7db8e.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cf71ab70ae08dee745abc6b4c958db0',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/9da04a2e008e97f9f641acb8a6bd9dc8.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd36022ec35c24f2c6fadbd336aed152a',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/3ae51c77e7243615dcac6e73802547da.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54c9e9132e80e4f8b40c2dbbddb58866',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/c1bd60fae2010e901d486495676941c2.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b25430956c2fb4df304d257261550e26',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/e5ed954292b9bc8077b4fcf31250a8ae.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e7d6bb4a920f4005c09c2465d3f8f4c',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/8cd67d41f11fe6da6131998fa25d1d18.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebf026429b129197c6465030ef125669',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/019bcf818f6978f9a11fffd845548222.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97dd4b40aa017904b54b5d0dedc37193',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/15411652a44d7c0fdfbd95131d0b686d.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5a7654dcc0a92f17060dede01825a06',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/25a46364d9eefbfad2777cec6a5b1843.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eed67de42c70f4cd909293c02e27f302',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/09f27ea93652badc359c8be76c700734.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aed95a7596ea522f7a7e6a0740e1c0d',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/9eaa5def305477d50b2b3a90c7f01130.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd98dfe1de83ad06468db5b9038599b3',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/9e59ae3e2e13a969f9be36f6054ec206.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81731f0070979adbe6bfd9258a64c79f',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/d22efdffb6acdbd4df460041b4110643.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b48dd37ef02bbeceb10ece95f4564b5',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/d74c31ba613b77dc11f8481d40c7ee16.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2e65c8361938e438bb413d2996872b0',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/1e9284eef925abe0e56e53d8bdce875e.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2f92a6070e1268a0f6f8e5343b44ece',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/45fdbee938a7109d160eea4651ad7752.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c68c59253296b5401b88234675b5445d',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/060387d445a37f88ce897f7bd86efc8c.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8948595bd1588f5fe76c4d13fed69ba4',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/f2172dfb0ff22ba5ec77f10c840ee0b7.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27311951b63345206adb2b04696bb6ba',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/04eb310de5abcf9dabcae50f8276026a.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '437b73b9f429943cf1ead4c737a3e09f',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/697831925d42f338687d13d2d32f3e39.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c8905ed2789c49b932f5aa5809e189c',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/c19e444cec049868ed8670335f446fea.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '314dd87bfbbf4ce5b81c9aae8977348f',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/75a5cc95921bf291266c726cf2f88a30.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75fa40aa3532945378a25e8c9b74ccab',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/a64d91e42de82dfb0f18e0709794b41e.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32adeb7d5cb44697783cd10a23408964',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/7343049dad748f57be4692f6a53fcdbc.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e69421e3d793667e30d8ac0855c1071',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/5306706905704a99250d02fcc6b5858f.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0df08af00780a25cb60c6d7d10ef692',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/907cebf56a7dcf9a0e6306d9142e8766.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ee846bb91b71a7a265b01ff2737a14a',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/e8ac96f5d0ee01d68f470b64ad99a1fd.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bab3f48a5be38f2e3aae5fb00f7ff09',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/8a12e94054b7f76b2d5cf83e0604bda5.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e5c2643af78faa51caa03d43350ba4a',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/130f8a8a0e627b9dcb13a73a1669ea13.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6267071bccee90a68f968e47a5421131',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/5933ec685e8f39407c30b79e4cfeef79.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0b9d6614d0865e0d1082c1259884305',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/4f3ebcfb9218709b714f08b944b8cc0b.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95400569fef2036e4baec2bf2dfbab6d',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/a08e406a35fa545f372023b95c15bbe6.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '687392eb21a999973a919fda9c14cb80',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/3cfdc49bf267454cba4714f3265a8baa.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ba5889988e90c6fc84280df191fa9b7',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/12d5e85a6b174c79c6987e683e7a1693.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22a2296a47fb97f3cfd535a281e04e99',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/a46374a4259b07bd0bd876b296e0b966.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a741fd1b3e286d91ec2d889d3d87e222',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/bd13678c18cca56ccb547cda19338189.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '523aff373f35c02a3c7f84518bdd2577',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/758fd1b3cd3c70f057ddc7bb99d0fd91.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a89fedd90c3c519a658aeaffdaf33df',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/ab53c588607b30a63241b6633edc18fc.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '315cc35bcd2032cc5b274ec476c8f880',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/e8532d523c15d82591e210409f8fd939.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2e4d519e13ea8697fd01463539511da',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/72c7506feaf6aa55787f9511c4fc90fd.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7fc4943da62067fe71604169f8271a2',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/ca1b9c19d15b5677c57944e75e97e22f.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e832fc221356fe4b43f675d824f21ce4',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/a08c277cb79a3f4770f78f2a32be22fb.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2482cd934b5e5df0866e5e358f74014d',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/a6761e972a41663d708ebba62c7c91f8.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9943064764a695fbc901b256ffd677cd',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/d9b73eefa57f132456b61305898a6f5f.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13bd709b4cac2bcc5df831e88b3a19d5',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/de9f0ce0299437d1a4e81727e118c3b9.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6cbe7f010dda43f767855c0089d276c',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/bbc78ae0df6f8fad0a0f6f35d96ebecf.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a79dfed4926b658b4835291d194ee8a2',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/96c8e3f2efb7d370ae3218d88de1f19e.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffd29b317a7cad1e9e1b4d4b37edc08d',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/c0fb01d09953f48d00078bfd3191caa3.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b03db552f982c4efb88a6c1b767b1e7',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/0c91814f2caa844cb04e94ba7dfd1e76.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd673cbdaeaf06107b79e7fb306215033',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/59cc2c77dfa7dfe2afb6b7fea567b4d2.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b24688fbfa860c309c37b6b981ec8e8a',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/f1740cef6744e8a46357225fa26ffad5.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3136d9c74b9ddbe6c002ccff373df2cf',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/2055fa0f32723fee88e7484508367112.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b22bd127d1bc81ccb6938b920a3ffed',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/6480ddd031cd20be2d7e5fd0b1f2ce89.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa5e31fb2ead3074cb2ddf4872baa29d',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/621b92716eb04319beb7905b8b334be4.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '136fd302dc7ffae3bd857be739aade67',
      'native_key' => NULL,
      'filename' => 'modUserGroup/01bfaed4ca1f89673dc6d6515d116a98.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '30b5e09e739dd0020b7d700cfead9037',
      'native_key' => NULL,
      'filename' => 'modUserGroup/cf32e7613d003b06d56fa088eefd26fc.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '920395d30916a29fd1a8055fdd4bf51d',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/77c68a31da0cae8bb69904721b266ec6.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf608e71521c60d0a137d803748f49db',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/4de4cbfa77ff7886b394c3f5ae6020d2.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a58da57cd7b89caeaf04cfaf4c5572d',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/837278a0e265d75d0b6c8bbbea3e4cb7.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a357054a00f438288b30d6d08f9cab7',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/14a0fb7a02a8e4d164f02133a7f6fa40.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '627c3f90da96d139fd9b6668815a65fa',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/073d2ec7b84fba0eb4edf27216e87091.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc48c675206ad31c5529aa52118639ae',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/871bdf2f549c536d3a98868b1ae58268.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a8e5e293e4d7173ec32111873247b42',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/9d575ee7fd18acbef79a4cd3b49afba3.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ef368343a6d0268350f558b039416f1',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/4fbd1fdc7e969ed2048f0045638283cc.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a11b71fb602dc16bc00853d710580738',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/1fe0d01dbb8f6ee34b73fb9d05bd9155.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8d53af6370a2554afe05d85854efe0c',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/5779becb3f02b989402cd0503e23c0c1.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c018de67c2a4febaf3130cf3b9cb7b5',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/f7532a362a2dbcd45a57ff3ae4ad77ab.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f37c805e1653ea33c3236f1cfbeda38d',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/4f22594614e88cea3ef1e50b9ac1c960.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7f6f41808749bd3229332c84ab50a4c',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/f8de7553c846109b409321428b61eaaf.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2da5a20141a4ac7f3075b7f24c64f028',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/58b1f63fb124563495a41eb064075017.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3db68eae156b53c435d026169273111',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/f4166f6a1e1d860391e2a534ed13343b.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0cd9efc70dc0358a23e590f51df4902',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/54bcffc77d9aa8d5c6956f176ca5f609.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16ad456f62e4a77b262438ecc66f0c71',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/d15e2641a1196443a8426c56954f3024.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '498de6365b961f99f038be41f11bbcea',
      'native_key' => 'discuss',
      'filename' => 'modMenu/58ee4a08c105cae83a08cf0ee175d119.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
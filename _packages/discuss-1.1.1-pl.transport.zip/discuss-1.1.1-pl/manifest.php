<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c97e643e5410bb4dded637079c03eed1',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/ce77aad02d21399fe58da6d8e701556d.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '950e6459bc77e9555576473cd5abca34',
      'native_key' => 1,
      'filename' => 'modCategory/f9d9df6cb3186e8f091dfb193689787b.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '54823082e618f7d01f14bd0924b12e11',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/d1d694ec4cd87a234cf1a0a4db7f00ca.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1bf254970c8f17de3c1ae110ba374110',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/904df0eaa21b3f6ab5456865b40a5d19.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6deaa41819ee4933f5cad62078f25bfe',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/422ef4b9f9abe62b7b1d1c013da3eb79.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'eaaa321de39b2d487bc2998be2e2d7a1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/359152c7e7bb8287ce529dfb6c8e4460.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d8ab58a5eb244af1788e052b620fb87',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/3ff40d9f6d5dcde0307425c482088bb7.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1052cdcb808d9c882669d09c0b5a8686',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/774d25615ac836b6d3c08e993122f9b3.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c8522b8f824854805aa2fd4bed45d12',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/4d445f2a1ba2bb075fadf3a27e50eca9.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5074f1a69e942ff15f303cc3073531f3',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/7062c924b8ee60121ed9f041e3600c80.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '151e16ffc7e75cbdbe0c1c7398740d2e',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/c8da991870bea5d134963cf88cd0d412.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fae37c54fd9450aa8d0efd3853cc31df',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/9fc2c6cd44cc987ca7210fce0af21f79.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96ce4519a1c9c101845b446b9e77a2af',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/376a603e5008fc2f0f8c205f3ed868d7.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c49524eacfc13da1b0116358062e1bf',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/0897a5ab8dd1bdadf5f777b37442bcea.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb32562a6dc7d2f625b0cf180e408db7',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/d327c7d6e03d2789afcef216ee7b0829.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e15fd75d06117f9019e09a12d587316f',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/71b85d1e792334715707fb61772fa327.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1178b023050ec75d852df5135bbbc693',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/92cdf1f9a1d14be45515fcb52d062511.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '690cf872d06907d717ca1406e491daf4',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/531d0e46f7538fc3e682196a273ddd8e.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3fd0c8f57f66348ba03af4c94678ca7',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/f4e22c9b38fdbf5ebe3a8e7d7101d805.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6d1d70d656642858cbad567fadb225d',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/f15e90431e792d48469ef30b489d8d9b.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7698cca912fe5b9fe4dea68c82ec6dd',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/eee6c14e7bd6fbcc5c8d5186b49a69a7.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37d6cb7a2241c3d0e73a6d210a9a47c3',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/d7cec33691a272155686dc37c17b72d5.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '352cdf40eeea5a73cfa1ad9c9ab38277',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/e5845618146111ee1176892de381bad6.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c716d8d28cc35865369ec3c855a156e9',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/9aeb2fa557997969b0552ce5f09bba9a.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad2ad2fc8e5b63b4abfab9fb359c85b4',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/ced92fe0f11171bcd17707db8d3c0193.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce42e3243b5933915c19ac518d967dc4',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/6a0c58788b16a18602f2d2e5d497dbc4.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9da46b995fba35b92f8f07a322bde1e',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/e4615be54344ebaf81472093144d14eb.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ff280f5b3dd4468d731c72b83d9b433',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/e1b7576fb7a649272155e6c330b88c6f.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1515257a3adf5198e72e1beb523301a',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/127f7b2e2b6730aed1cdb9691da686d3.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44ed34eae6d214695caa00f4f6f67440',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/19abf834a19c443714428fa6b23df264.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b65fbd80a7b31291fd6c43928196f69',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/642c0c807c18051bc1ad4b9169c2fb3b.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a520fab360c34b8a175fd415aa724e',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/344d7bd7fbf405b7295209e3f4cbb87c.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a60c68e1358ee8fb7b9286b021074b35',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/4500b1f2f63e23167e6608dc935e2bfc.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73c57ec236181b1996abeefac1a90453',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/cbd1990a1ae763236ecde634694c1f96.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e312059ca8211b0c4fce5059014ce07',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/24e71ccf499b1f2fb5368dd08da4154a.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71c90649edb0e4ff61396302ce9a4092',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/a0330c6faae72dee8670bde8100db069.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ee1909155a7ea0e1c395f7d8037b67b',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/f85ff666834205b222ef4511ae050419.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c29b3f8641550201b99366900681b348',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/b39ee957798a4c5a64274f45ceb09354.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0055b55d37070ade189d2abb36acf417',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/4418cba753a1718381e74e97f300331b.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd463ec3e9039308c7d0a0a31419d0be6',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/8f11649313660c27a23e39d6d724478a.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af676626ca9c14096257a065677ed0bc',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/1e5c63f4771d7a7c93798b35e11c3ee3.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02531562a066808d12ee1c4608d326be',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/719da759621f5529193499c14bdf211f.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1e358d8aa45238e190b812fccce352f',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/333c12ca7fb717f21b9817c09dbe8c0a.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c16434a8b77f6b93fd3d05c44163d55',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/ce7848b492539c9428b1f307a3655951.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56905c2f4b73c7f730df5d5fb90d7f74',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/eb3da4b8902fbf5e556aa0515ea21afb.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4425b38bb1c831b8850e53cefad36ccd',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/80fffdbc90e86ac1e537e166b3a080b8.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e1b6222100d59bbd1e347590cc11969',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/94d6c0e4105dac77ca779ca442ba0333.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ee96e5c66d20e4a20f2d87c96124c5d',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/5aad9cb110bf46268856d7370103ed45.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2f9787e7251970fe415bdc975c26ced',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/6c5e680c928696a6c3310c07e1afd880.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3fbd70bf433f03ff3e303ba5e000925',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/9c2676daeb2422a2f07c142379fb1152.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07985dc81bf650a43cf1d592b24ff90a',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/dfe4782bca007d87daaf9c0d2117ee4f.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '160104f540f9d05124067695e36c4ca4',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/bc8611b25a327389bc8247bd029031a3.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38e9506674c85935392be77c2e0b53b7',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/e61e1feb4cca9514b1181f67dbb35432.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6aa0574186f635b81471c2599be2423b',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/0b40c6cd0a1b80d7d087c8a2614550ce.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea3de249c547acd70d07c4edc21b0bff',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/1f6f97572b5d0b46ac9c6ce89a300f13.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a967f81b687dc1f4db06e7c6513c2a73',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/ae64188f2e9f15573f81ef364eef2a58.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2c075b5d5a7d7ddff93a1dd56a221f3',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/7601450f6df3e1844f63de98113af15e.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63f45f40e530973e656f91b811b49f84',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/8e120957449bca6d8a0a96a890acc9e3.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47c03cc1883575e594a64af3ae72456a',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/8d2686711e379aa6afb3b8f5aeb785e1.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37b5b254295035ce8708e0edfd9e4737',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/f564e73725541bd6db884880aa88fbd6.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89f62af46c6c897def33e81154ed9d48',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/228791fb4582837c1bb3b01498496748.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec695b245b9219c6d55d91b2d78be8ba',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/da64d6710c008541c6d1df4b63526eb4.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c756e41de3c2cfcefe8ab02cbb00a11e',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/678845e2969f9e40762fbed974032499.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6493a65a501b22288a648d5366193dc1',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/4a45a32dd6d9f3a59567bc3f998779fd.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc6a28b1ab5de6bbb30eddf0500f1afe',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/0e53ab97abda71652f9b2fc5d4a4c898.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caacadfd25db657f5610802c637b31e8',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/c5e2e088ff79a1f615cd5f92286c65c7.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94ff3bbf5511d9bc95de4c6478f26cf9',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/6ec60de47f7313dcf9fb6df1a03c42ba.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e2e45f54774aba07e8e19438a98ee2b',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/7a4079ac4862d04457f598c3430b72c6.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c6df68309952a9b22ce689f397ec065',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/bfbe8fc7feb3e32b07aeb82ef5857eca.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5985fc1ecf973b8b38ecb91687ecbc06',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/fb1fd2b9b4009c819354f9d28225fd7b.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1d0ef32b621a82ab5ec02e915ea0cdc',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/654d1d42e672efa9cae477e22f5da485.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '606e41532c12734f1f35db409e89753f',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/6959b6cb2509cc05db287f88bed3b629.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e95517d33b9e257aeab0fb38b0fd1a87',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/24b09782d47fd126a80b927fb4af901a.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '373bfb2de15214a0366bbaf109b57e44',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/858a851135ec5e1914450657200e0257.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3eb28eb841dae25885a8046b85d0b75',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/1ee4f313df3f5a43e1b5631c2c8b9976.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4806e9e4d0745e694df62c86e4aa6c72',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/9e1384935b1a1448dc1d319e74693538.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38a8ab924e44b64f011349e7ffbfae60',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/db6d5824097dc488f5f533e4b4755167.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d62c6c965341d238b6a02cd4aea762c',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/b7749e974c608a310103e7336812956e.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '881b138d74d0a91b2d992a2587a09b9b',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/afbd576b9eca3e764f93deac54df6ca7.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '003394451791767363dea90fbb455802',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/ca1936bb3291d868a45539109a03d54e.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afe5b93c4b99b1d28132d4bb61416752',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/0469419620a0295cd24cc28d1c858fab.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5329813256152feac666e525a7593296',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/6313a6e2dc90f149d45e4e4afacf2764.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '971c34c6e515c8c3ce8189237ee029d9',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/e4a6bf1010caaba0ce5160e39cdc9a56.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43a4ea75cf84894fa8c352f5109a0109',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/226709f3a4e316a3076e41ad67971d5c.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'c4b9a20e6b919b0dbcd7de64c995d5d2',
      'native_key' => NULL,
      'filename' => 'modUserGroup/e808d0b0ba0c25a8a6b892492347a8a7.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'ac3cad40ea1cbab627987a9f8c4e6b90',
      'native_key' => NULL,
      'filename' => 'modUserGroup/a203265c6fc70ec28a87e07ab7dd343c.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b76be317b40f7747d870179ab3f79f51',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/6bc3b9f2592137b7398ef1c6575bf6b5.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d8f0346793165ab40cb00b5d810a03c',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/ea0dd03b2f0fa5239dfe659368e2063f.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1635c908c5986b031991979c989f76a1',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/457a530ba996ff788ec2754bc4c7da6a.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5cde168bf46b9c055f622bbca43f63e',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/ada8fc7d466f690a8c7cc4c37f9d39b4.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a49bf6cfe98e1794722b27f046e7b51',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/4ca5063835ead357d8fd4bd337793499.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cf2271d93fe6a4789c3dc0dbaf1be94',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/77385907d8319ee6565df892bff52bcc.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '480e253e20accc96e82d1aa64a17d28d',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/246fc5edf3f30d02b747bc3437f2996d.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c35316257cd10567de34dd5c1c705db',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/d28d797d894ce012cee82f000fed67ac.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccb7b724b54a7ef9df2f38d6bfa40875',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/5708482708ba17d2099a7343c0e78957.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23b0bb4dd1d37158cb5bade6af7b63c2',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/ba00611ea4266ed96390d2d9968b2f9c.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad8374e43a29b44f1b3678edae77a7ee',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/d652973de460fb2d26c9c046f0b6d5eb.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6aa711950c073302d49f4c625b8935c4',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/da3982a86bd3b4af094bb8bb24dc0fcc.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4498eb2339b71f52f6d4439ab563aabc',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/137d1a28f8bb7cc4de2eaeae5e7c2bba.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75bf5c8fa49a007f0a66dbb4e895f2ee',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/0dd4f7d8d2ddf65732ceb786f6af2c58.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '665c361190f4e71df3bd366180b56420',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/1d1777ac94993cd36252b1f7120145b0.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47004a72335473efa62b2961af249482',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/832e5d86f4f29547a23b53e62db6cbfd.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2dd858e393ba1d7ce3085f73e49f745',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/b889b0ee3144f8d7e4ff7bdc5fd0e5ce.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bbbe7f8451712623bb5f9c74b55dbca3',
      'native_key' => 'discuss',
      'filename' => 'modMenu/e2c201e34870246236501d40f1a98e22.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
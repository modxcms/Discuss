<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3b34f748f673520340092f0fa22e0750',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/1f8238459085adeba61214349b78d61e.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f201e79056b86215a88286a875be0c51',
      'native_key' => 1,
      'filename' => 'modCategory/e28cbf01ea2aa1998b234be2e9eaf351.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2f0afd9e194cfe010ed2294633453626',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/eaecaf24d6f5650b41fd6a55e4d59fe2.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '202cd2bb866a9b14a36b0c80e97e0dce',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/c5cc7020872fec1808ffb30b028bf87b.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4520f13af7758c7c69bb7588a97ad1e2',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/6d3a722f143627fbcf614d770c9e61ac.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '56969512d033d55ff84efb8748430340',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/309ba6831f17fecc17b2ca11d72e8886.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0d5ab7a2c17f4351bef75bd509673db',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/cf0397645dcb0208b681bc63009abf19.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f132605f00ab2eb18006aae5d2ea5996',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/976ef2debecdc74ca240eb7424417411.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f4d17c0be25115321682cc68c8059a3',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/18bdfc33e2bb7b15b9387f19444fb77d.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33122f098e49556b465721e366385ea3',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/796167c9504e2d841e9fb423184d9581.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01c604ebc14ded8f6947714730e85b80',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/62e0eb454cfaca7913b4a82cace17d7a.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b4ef673b7a6ead04cc3dc6a8b361301',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/9ab5b89a9d73924387b8695834c39ca9.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52e65c92faa02836f81c3c3d408bb872',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/60c4753c895ea44485774711e2fbf5b4.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f25e480e9b6edc876e953de2e281a7ef',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/2dc04a83800c691fd5371459a91df26f.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7ccbddeb6ac51d93cdb5766a45456a1',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/ed803a5dec26b47e1bd2797195171665.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04d6a52dc746c6d14d17c4cea655f04d',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/07396934ce5936495ce70d5432414986.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fe0e635d5fccb445b90846c079937cd',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/1d1df3710397a7b26c634145a5c0f607.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3588088e45bf8bca753fa0f7da589cf',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/45358cebbd52ebcef831ea68d1b5063a.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddf0a5f8848457f9c8578cd099052d15',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/afcb6474c606fff01490616cb7bf45ea.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '207956098654df59f770899e5d63d3a9',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/07129cef3590095589faa513c15cb84c.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3f39dd59f443bb1ab04398519b82894',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/f58d60730227608e6b734a4c1e9236e3.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2eaaa4e9ec1984e4ddb12946a6404f1',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/5c9f832b24d23c176b2176cc5e861508.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '961b2c2791640060d12fd78697af5206',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/97458820d30c9909bf7bf1f13c37c5a0.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f12d9620d313b4c1afba822980f9cf5f',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/1335c0d65e37ba3e3d0c84d160023b5a.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '914e7f2ec2d4c32da8a37ffa7c73298d',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/e44968066a688a8172b917e54d495a59.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aafeafede712dd120a25daa57a8ea4f3',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/2eea1df9083c6c7d20615ba57be4dd25.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a73b03ece9bc6d91a5fedfba7aa134a9',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/0296a6ae4ac248aa06eb6a1687e41adb.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79dbb8890f871d773f10d24b638beca5',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/cc924f87291a681fe39f74ac8c387b09.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d89292b3972872a24fd87d6d1e8be76',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/1ddc6a0925e994d79e1c106d44d313b6.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c27950f8613a32c6278161ca0dfa457',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/7d01c74f78004f72178cca00209c84f8.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a590479e7750dbeeb8c188503c5b73bf',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/a6912941649e9b5140285e7b957d7c97.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8d26c4954ec611ba73cd78da6a92f0b',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/6f6629f1b0836eabfed6f340843e3d9b.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee1dcf1ef5a32f522900a83315b04ad0',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/e3119a13673dcc9f151993fc8ab57af5.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e42ba2ebd96f64468c1088e7038c765d',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/fc753a50bf4153db5e0f162c9986e298.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24c8749d77435fff629948e0c1f5ed46',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/00381b63483154f80d2f93a59a7d9a6a.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f2fa9e5bf7514d1fd84b6cc4a5cd6fb',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/12b162907e0cae545c4b562cf9a23eb6.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '253b55e0eb8909f54ce48ff1a6b66aef',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/0b924a7851d298de8aafc2e72efc617c.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '853225bda82acd072f55d40d1813bc52',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/3bfc579c1289e6f378930ed46b5a4019.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '286b24ebde9e92933e53a80a9ed879d9',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/c3102e51ea0e3e12b708435653baf4e7.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43538a0f675723fb32ffbe2706a0f021',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/4d5869d645d6109ca60f2909d5b26f2d.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5151b0136de091304c8a13aa8f800031',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/2dda8b64595ef4f44334f161f05a9e58.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4110ee9746b53a861b7eb6fc5dea0f56',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/98054c1706f915f368a289232dd5d595.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9957918a261418bb0102add947a757a',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/9a19e033e16c7d4b9b74e536b99aa71d.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f22f68c349bc528a2f88ab6201c950d',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/89b12236cf4fd133d187402ef54254d3.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf300c30159ae67219edcf2e2edf6f37',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/42d283786a14acf755e4f8d421c1d401.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67f85f2fe90ef28215db35951e8b67f4',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/09a5b4f0ed26d620eef2f563d8077517.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c135f061ca3dc05122612bfe609711a2',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/31131b85d0f658ce78d2917693ab036b.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0d65bb76be9d70c061177fbf1503a18',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/4fbaef1de13770c6cf707d98c4b551df.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e61d500ab6847672f2b786c922e8b174',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/f53a80af56bfb7353b62990205e1917e.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3002fe41205447f668bca0c52227a02',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/ca9006a804679e5a8ab78eadb50f562d.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12f8c2215695d7b98d01941d057ec261',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/ba6921e693d50822354249f291f7a179.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c92b4a5dff1aa59cf285d25d92d24425',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/f307c84766cc557fbd7084aece7c1a2e.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aff48254392ceba54f806144c45b744',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/da05b74c3761393ebe4c1d0436a7f968.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e184a5a21d19b0b70bc61ac26de89d6',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/8b62b74ce1f9db370b555f5a426ae1c9.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36d446f18fdfa97e6f2dda88462a4005',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/7e575a153f21c6b689cb4af5ae0e911e.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9697ef9ae4cfcea9c3f705912e893001',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/0d868d10db286e777f5793119d989175.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14ffe45191a3385da8077f2ee7508eeb',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/ae2fa49ed00852038f5a3df61675d6a1.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd50aa619450b1edbd2157d0c71b247d6',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/2f985e3ba237dbbeeef3daf1e4fe688a.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ea8eff7fb4acc19bc8eb2db0022333d',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/950f45d51de6356964610ebfdb42a964.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aec643532492ad8fea9fc8bd6c4eb51b',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/59e108850afed50d8cdc568020ece1c7.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff278f8d1e85e1ed81991cc9a270f9da',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/859926fafd2009d42cb1a5330d1dd759.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5506eb0ae34d6eb9e0d33a8c96387444',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/eb1e66962695886b82585d484eab25dd.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2d85d2fb3c740e71fc49366bbcf8381',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/23fd01041b16705e9a9c5c5a74151004.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25d632642454b8448c1e4c1d67de7498',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/5b288e89d650a0830eaa4e83c8227cad.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d3238a29e5b6bc60ec5844a895c6585',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/acb74ccb5cc622fb2cc9e12e9198ce2c.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12f319d5331663e0853d80eba4b21696',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/56d52495315fcf2d36ecfc2a7952b875.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '352cfe9b3159fc78ec1ac9ee32d109c5',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/d2b284a125538c1bea6916dce7c1df86.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca499e5ec5e63bf56bf859204b0cc044',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/ac46a839401f3c201bf3c426fbe409d4.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3c51581ee8084a55a16e41866475f3b',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/56571bede00d32b54b0a7be27932db01.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23d467f6fbd2c865b5d85feb29c2899b',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/d85239895a7135a49303a0a19156de13.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52191cc9d092952621b8634160c97dff',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/1dcb8f52214bcc47616acd0f3dddf45a.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a05fa5ce3c26f80873b3b3f24f02e63',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/b0822177697f9415d0829d52a8e80a5d.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dd757af5e7eccadfabaf9ac7f943f16',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/587f7a0a819b9c5b335238512141c0fc.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db2215784597b1b8a9a42a1c6a692907',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/80d19665a06372098abe8e0de3796095.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5aa7efa6a17fe2675d9aeaf47190074a',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/f66c578c6c80fef749982dca7752f107.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e15e25d7c125dd94d67cb803ef1716d3',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/75a466c4eae72fab99cc242b3d44b853.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbdc645ced8f7a46138367c464aac7ea',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/a49f71d78ad8208600c5cff42434768e.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '316ab203cdbf5783d7c5a6e7f32b2fcb',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/63a039de0c47ffa2ac21fd634cc0cc72.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96be28568abfb644e8ab289c9255ce31',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/5558e2792167c85c725ae718d70489f9.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f64b107c35616c58ca27832e3a538dde',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/c2ed4badc46193b14daee5f96f53980b.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2adcfed173155fecdd97190da1795f86',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/300caee360445c60dba051c2b0a24f18.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8e40b8cce70b0e93062d0064e7c04b0',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/5ba1b67b3caa4641c0fd9c3cf21d6469.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b3eec0b4b7b83791faa31da2f38e4ea',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/5b5966e7088ce32ada66b3aec021c691.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1b190f69f1c7b637661a056f0c0388b',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/6f3ae9279cf8cec4abcd9d9b93747921.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'c6edc72542babf4f34cc129837043a2c',
      'native_key' => NULL,
      'filename' => 'modUserGroup/6453c718303cddb4be39312fbfe2e506.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'f2cdaa7fedababa3aaf6b4faa1c42db3',
      'native_key' => NULL,
      'filename' => 'modUserGroup/85435197b545ce42684ca3740640094d.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b51e4445466ba36f8f75ade7157511a4',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/ab8672881ebd08ef0a18076d17dcf7d4.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbb4d1edc79d45c368dff58e2364dafa',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/65e4a053452894fe09120b6ff8d6083d.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f6a28233d4f58cfd0b5ee5a413b8e8b',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/33aa4fd6d7d83ba840a90600833bed27.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39a7b1ce34a9d4f3200f804cd1d7f84e',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/a8cec40f6439f7eb6cfe140e082f51a5.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49ecf82cb007209e996001332daf13d3',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/681bc4e52f79f0baf5cb55acc07410e3.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edf30207486d9e8eb7d89399b44d49b4',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/5942959ae8effac7d0b52e6e6a21268c.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4f54573d229239895855f2639b948bd',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/5b7b18d123896099ea5999017c8ac998.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a50a9793a179c32fe83b3ec9fab7335e',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/6b44013ab64338c995fb24aafb84e6ef.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ef93911a9a17e7f74dcf23326dfc123',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/0aa4e84d3a694187f1bb08d21cdfd5d0.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e06ee156fe6371b6ab98cf19a3ef361',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/ed0a4069280dd3482b0053e9edf49240.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c5c1ad763863770a6aeae42df171a3e',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/b64c1d33378d2d324521bd2d4c8a5f80.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ab2d01675acdd313b4bb2c8f5282d92',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/0e09237c5e7aca5f9ea03d8a9bc76727.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9531d36e73753158034373beca79fbf0',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/62c10ef72f356426ecb2aa0fd020f440.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7875b70fac1c9a945660a5bf31f8f43',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/14cd01adfa768546cf0d7f23a4cafbc9.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80b67765101ad627bfbc58db5c313063',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/366d5210a560dfb554fef2cbbddf5480.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eef9065919ae8a977cbf3459c34d9958',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/3df196ade177dbb7946a7943101875dd.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae0446d8a8ca4290cf460e3601880a10',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/65ebe0fe0708d52983ece42d94a0d8ab.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b9f0c6bd454e7818342083bad2ba5ed9',
      'native_key' => 'discuss',
      'filename' => 'modMenu/4880c364e6f2b26d3009c2489808f4bf.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
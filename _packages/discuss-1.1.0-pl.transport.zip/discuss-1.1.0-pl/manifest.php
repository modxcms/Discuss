<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'df73a8229118dd08ec4c1af80d00227b',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/e4e9a2764921788e0774161ba5edc600.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e17afd2aa2941e9f974fc03f1e9d645b',
      'native_key' => 1,
      'filename' => 'modCategory/41b817d0b1225b28d3f3d4e131bc7204.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '306386c2eed0c58e3bf4e9adca6448ec',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/e1f0e8582e541a1d138e126e05a183ce.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1a8d48b4e4ab6aa9935d3273690d8047',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/8ea734136ca80bccf1ba791bc408fd81.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6861cfe16e4776233a831ed9da0e6f12',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/f4d3d643d207db33baa32a9f7369db7d.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3fa1dfacf7c9489db19e40bd20c78fa3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/07ce464a5a8880f195944dbfa0f63cb9.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d50c76af8d1f87c5b94427df742cc16',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/a0ccc2ebec4411a25539ad3261ace31c.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5484da64b00271bed95b4b3bd7e26c78',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/2e28b15d7f4bd99ac0c536fbccd8211f.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfc82c181f5be58ada27c269be36af91',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/e3e8696146d749ed78c0d854ab8445e3.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae42561b587f2e5fd548f7fa1d60c453',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/2f8cbcd380b7ab97eeb7d3e00d1423d7.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48a548d1708742e1beb4940178cfd17a',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/cbf321747b0fb2be05872bed03daaea8.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fd63677b8e6af0173be70b595165754',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/081b13314cb61906dae2f6725df6b222.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33d3cf67a0288ea9ae2de1f1b3cb0746',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/6b1eb66319696da1bd49beeeda8ebcc7.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff81f009b5d59f4e4e018a681e6487bb',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/f46396e4255cf82dae4d6bca9aa7638d.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f207709b763b57cd2943968af3381777',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/9785efd41ddad494bb719f99c35a9ded.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9c524c78269a3832cb06cb03c0bffe4',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/3cdb81336f5e0f697acb17a1f4b06e27.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0bf1d5454aa8b37c123be84754928f1',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/5fed7161708cd6d31678f64fef38f4fa.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a12f4ba927fca939b7d19c51075426f5',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/68d75ad764e7a99e61e7df95b8e9d373.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5683cf4c18ec2edc6cd10b9f1954dba0',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/450454bb0523223cbbc2a835cdc0e123.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4660a441cfa0361a4697b0a7d6ff190',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/4a107b1cdf90218eeb2ef3abcf9f6b36.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a47b089e733bb721971f39a54a0c91d4',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/55b3c31e1fffeb0d5b84ec86b50d5076.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdfba2ea591f4c6c2d8e11901bf94be2',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/48054565b9ccc284dfd41ab27aeb8df8.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f9df45981ef56ef0de001673e69788d',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/385f42a1d96a919b0cc73a9243e7016b.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bea2687dd50c98b1a4b4f85b523a4a61',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/631f2ccc857990f368bf87f94742f167.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee2809b580c8d3f3696d06ecd3a89899',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/fc9b950b80e1bd70f9767045855b75e4.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f8072a5fdcfa8eee60d931f8b71c795',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/4fe41d1426062860679be150f3690798.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e02af29da8d4b44f18026fd4b861318e',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/df7c618d193f54faaf61870479099837.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bf7a5218f84443a39ce0daefae3603a',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/5f36a8a3cf85d5267b43e22c40af18f7.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e04cdcfe6a9d12dd53b16976efb0f904',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/50f1bf65b068337435240d6087d959f3.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4bf43c6598faa2199109d686c7dd6b4',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/dd972987adb8cb5d6bf5d5d483918d99.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd3beef3f3a3f0b0201239626c417192',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/93161e831c11a9f463683ecae43709d6.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc917af19b3325e8da9a234af18b084c',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/d1941270ee9eb57e125d09354f3f4e3d.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88830df4b54913e2bf0d14e2f1a697c0',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/fdaa91523396fc1a9729617c4333c902.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07335d594ab8a4a72b416d073993199b',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/c94cb12c217736f895f92d405c106d6c.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79bffc01dfa80440fcab83ae801f87ce',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/9e3849428979a80727fcced71d8a83b2.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d009dcf55596c65fab1e0bceb044ab3',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/b4ec57e96f6b525bd4568a5a0900cadb.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b550b77b1d99edd3823ec671e77b6bc5',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/9c256387f315a03bd9c6b32843b4e474.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ca75817ba4d558ad9f95e720f709576',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/06ead364f483f4c59bccd592f30be70e.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89636683cfb50e60de17e43b4c804caa',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/29bd1d5e1c9fcd825ff446b46fbfeea1.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8f121d6e5e4cd30e68552007cbd4b8c',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/7484fb9548febba009e667fbaf86c39b.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f9fdb9836834ef25136a8d2b049d046',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/8ade8b1f3a3c7f0fe5a44341faf29e5c.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ac23b7858921c6a9bae1406f59a0638',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/fa0585d0956e7f61b9ed68af9b70f402.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '545e548cefb09232d4dd56412a108198',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/5c2978b61936e861b8db0556ea1909ec.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b773ef401043c02260ca20682644fe33',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/895e15609ac0540caca5d025e64b2c80.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18fdd837bc1347e966208b5b4809aae4',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/2bca3964154f326b5d39d5f010ff1072.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a22b3ec27c140c0bde1c0b6296e38a9',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/a03ed2badbc1591b9dbac8dbd1550c68.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09e908691497722a24eacecf3a8b2b19',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/fef95c267bc821a681de1562943234ba.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '055a4a48e740af301ee1c5956906b85b',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/0e01e2907a74b497e798344c5eb0aaa6.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1f21ac9493990029d8c05c5ab106a6c',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/1411952c0ee5e5af62bc76aa1bbd29ea.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cde5c2584960fbef847a466fdf03fd57',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/e4d7371458d6781222d4f8d74b27be97.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b96cb96b151fe1d6b7657ea584ad00e',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/72b4d4b835f8d6d83496cdbfb746951b.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fef20c844243aee0f9eb59c202f61e6e',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/16338a0ff323b4652c33259b779f983c.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfe010508ad3c677a77f6ca3631892da',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/3a42e36481339fc49a5d0ee9ea905ca6.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7523c9363169791b410400baea17da5b',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/1a1e4de43400cf073dd2b450eddd6d03.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40fe640e779c3a0bf057c1e3b26b169a',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/a07b9ea4b63bdf5965a251dc91b09cdb.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd65709568e0990d22ac9123124567a95',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/e90eb006753a65e8ea5f128c0bb2dfc3.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7382f22680e02f60cc6543dce275531',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/aa7e41f8e83bd91ca119e55f95d6c49d.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6c5755496f6d135c27531b697605255',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/5252f2b19126a75a8f7ea72885f64dc8.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba026e1f3f74a3c61d7ff3f5c5e246e1',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/eb307e241615ec76098dcca7a1ee222a.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82cf0eb7cd669535aa1b18c7a5dea4cc',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/298d56c17c853a72c2fe26801e0ee0b9.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af36fd8ce3b72c4828d0e6d5752e1d73',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/01675d09b5221ec0a4c8c07ee2df7412.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f0675d75540c7a61b91fd59e840f176',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/98ec4a9959a49e765f7c43fb31a7631c.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eea0db98327ca0d4149c4dfb036fb6ae',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/01b6a80f13e7bb9b82e6c672f0ec9cb7.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0c0dbd4bc8801b926c77d99129a3c56',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/0fdeec997c63ac5068620fe1f5d913b5.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e26d50fb5201b738e3d43854ffd3eb53',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/ed387b736a277457e2154594428bb5a2.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2a783b004d298857fa19281d3608917',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/c2caad46e72655330454cc27a71800ee.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c0032ee69b3d3370ef39c5cffd7f936',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/adc35d4b382753e8b79d1157ae52b311.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0270f92163c32a2e617e8d19c7dfcd6',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/51376585698c25e465abc81e71ac9d25.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1189930c928aa9266602dd16804b5f2',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/2845e151c9587d6f9ac68b97daf62ccf.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdad0d10f03c473adc8c12ccbe6ee4ef',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/9f420ee934ecea243933c118df30b634.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd4a02274b2e11afec34b73ded2c7471',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/a3408a0e8b084408eaf59d0daf0ae71e.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73833d27afdfa741b2b589c0ef7ae883',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/5ea2e882336a235efb3e43f88a754819.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5d57f149bd5783e2261d89090e11077',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/ae7be200a40433d52c34222279982558.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c335bf28b0b4f930fc3a2bbd4297c50f',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/d2fd887112d84e771dd92811842023b4.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea36cd210726046588a1c2c5e811b18e',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/4664e5b02e24438d412c78eb10be7e42.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '464f4c95b9455c92be28b6bd348e8ff0',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/cbac75aab7db8aecc44d7429b1f35369.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c91d12b6a289297d4c3358282a603d80',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/6914a87abd3cb175085c789eabe20f8f.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2d5f8d4c36b5c8ace930be951b1dafa',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/dccfe52c8f57c4ba707b5f718547cd54.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03c371bd0225c357243db733c52f5bc8',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/14cea166c604ccffb0657846b9835632.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b67f8c807f0fa9f1700dbf8294e21d82',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/a8a4b289a7289fb6c5ec8d80004e7034.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a5d380732384a6dc1dd8220440cc002',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/c064a8bd9a2f7418402365da96e0c7c4.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f68355ee9e90c149f0100c25e57f354c',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/e7dd065b7681dd73ea367b26bca99354.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5295ba61720a7af15d8022b68830df31',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/3cba57cecc503a66b660a041c4b167fb.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36801812444e79ccb9026a0255b0eff0',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/37ed1a64206d600b748a7d05e8fa3f2b.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'b9f5bbed4a8fc1f75b9bd397b45b73cc',
      'native_key' => NULL,
      'filename' => 'modUserGroup/d11da5b2debd15af8e5a5725b422f029.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '3c5e0c88772b24cea183c0302aca6041',
      'native_key' => NULL,
      'filename' => 'modUserGroup/2e22d78c673f0c3016afe6e35a2dcd63.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21dc2b47cc818f2faf46c571560af44a',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/6ae9af8d1981007800aaabfe50908cae.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e13ec1954b99d5b6f3372519dc1f3bf3',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/10cf302ac7f21c49e4bdd914f947d1d1.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d9d8274db6657949dda4c6233584bf2',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/053605fe95e6d5bdd87ea1dfb96f970e.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd853e5223a49eeca81e0210268aeac96',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/86610b59ef165db5de6c3306582d06d4.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23421581e847f92e1ff4db6467ca4f24',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/e73abb634bd78831f2d91482308a7336.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2ab19ae02cb31d4a0dbe41e72bccbac',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/189df22106818f909b569d853229016d.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2797cc934bf8698525b6595eb180df93',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/d842969b0adcab21333e339a1fd76ae7.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8a529d24bda2a1254a8fb8c659dc918',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/1db42ec5e78e3c30f53e5fad888b3a76.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf0f613ca99d8951f9f71ef1be9cba70',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/3c870a678c44cb36ef5ce46db7cafe1c.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '914cb5e493eed1acd5ea53a078a3c489',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/c8fa66210b0639f3a198b7ef166c36c4.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c42997d1bcc490421ddf723d7d7a6f4e',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/23b23f30fac742e43cd8ab46fe8a3245.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f99682d6ec70e4d579a3de8991727e72',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/fc405f2856f879fcea3a8f9351caf401.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5103ae51abe1d51d8fbdd382b5089b62',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/169602e398f0d5c642c156994199dfef.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b511ba475c7355494ddd10a716a5213e',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/5bcab2160c771f14da6f7a86865cf81e.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3036dddf154c20d65e91551bd6aed911',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/d72c0e2ebab610d227bfeae4ce3c50b7.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '201e3ee0da993938843576cf73a38fcb',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/2e949dceb04d60735c274d08985212c0.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91c99cafb8ac6a8db839df8c50b9f465',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/bc44ae2ea35d880caccc7c623f4606fd.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2f6e60405a16bf790d06f006acc5cd7b',
      'native_key' => 'discuss',
      'filename' => 'modMenu/4b91fc9838bd640e3a2460abe8c754bf.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
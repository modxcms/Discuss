<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disthreaddiscussion.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disThreadDiscussion_mysql extends disThreadDiscussion {}
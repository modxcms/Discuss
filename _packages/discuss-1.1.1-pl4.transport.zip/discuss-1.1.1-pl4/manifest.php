<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl4/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '07104e4cb26c4d09d4a29fe39dd68f0a',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/c7013e1b74e116f55306ed65eab73638.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e3e186820083daafe1a4494d2f6a80af',
      'native_key' => 1,
      'filename' => 'modCategory/6d011548e228faa0041a58e954d9a64a.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a802d88b9d862f4dbc1ee88b2aeb362f',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/f3c550036cd1972dbe2c0be82707630d.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7359c5b6d6b78439d254d7bafe0b4f9e',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/d788cea9811d8557b4088182c8f57e74.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'efc75f8f3c1349d5b34371a48ffb4204',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/83e3a77bb832194dad6d17d3451815ee.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '672de42feb36317c6a6c5581fd301822',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/57539612361db77703a40e1820912dad.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b35055b60875f2e3c23b8faa3f7eb68',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/012106384152680a8d5a2beab00831fa.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62829542035d68ef24fff35cbae9a212',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/49b29afd670d8b604eee8f5d8eff9cc7.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '498e3faf0baa91dd212cec2994a060c5',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/33f6b663d866ddc7a202905e5eb24ec9.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afe188d97abc6c8aac8159fc7410aabf',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/5e9ae6214a34f037db080fe35877564f.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e91a2af050774e0c0fa4a83d1c704e36',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/e9a270276c9f4faffbd4673e480b1c90.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7a05e46fed64b3730c5d97f0e819c57',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/f6b0f69da37475d54aa8b59e5715bf5c.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48599ee9d88d66f32ba33b3eff8e75df',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/2d219821a6f60bf739b4933e57527ac8.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ed8b8d4bfab8f0072712627393befb4',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/97f0f0c03949d7d9d5adc5ddc5af7903.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '331d978d813513413cac3db4caabf9fe',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/07b2d2e0037b3dbbfe6ca39fdb42cded.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80ff455cdaf628c21946c64072515f5a',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/47d5ab755021201d017f324bf1e6e9a0.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cf19aba5a3caf1d00e363f69e726917',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/bf67b3a79af5e6174df21fd53f23e2d5.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38e655e432b733b3d8000ea4cf111e41',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/8d9a230b2c7ca71c2bf2ad9195e9394d.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f6c31acce5321f04460435782d07bc3',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/bdc8e7abc018054b4aae01e862f65dc9.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a58239907c477a6f3e2eaea5650a6cfc',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/d4b7cec23c28f9c423f56ca0c629f49d.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd8f716c3ae87cce376df41b9fffeab4',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/f27c24371ca13f56e1cb90182c65478d.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e1641fdded9895c34ba4c5fb74c575f',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/f79a30caabd936e3a09bd809d4943780.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3ad7c1bb9c825ea65aea6e8599f1538',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/c00ca4036d019fb56123043ffa86f82b.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfe4e78768b67dc6d17b76a2f10d8682',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/ef2408b15a1fec019325d481463a69ed.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25cf1e27d8f8343c1275da267c148fb1',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/3068b98acd34f963feb40b858809b0b8.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '465102252c228d1c2b117587676e6f4f',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/52c1bae3e67a545a137328caa9df3d40.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d5e9433ff907f42b1a8fb06ad97dbd8',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/fcdc32dc1178723119333ac676ef30c8.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91d9c2ebee8cd8f22196b50bb31a3bff',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/32bda3b4c5be1bcb7ff62c4e236e5021.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '603a6025a5fc9a53ac9289d9c2142435',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/70743ceb533b17d3838eeaabb7e6b1ce.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b5135b2d0b5b65a9606c972f78844eb',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/eb40c1b51586c60645841894c18acaf1.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24f7b99af754fe481eda01c84cc2e7ff',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/dd54fb98bfb8b758b9a741fcf1db0367.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33b94c20ee4ecf28cfec6e2a4a6f25f7',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/f7d053d09000feb97586da0e2ea3e8d0.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cb64c9e90db72b80166bde211e321db',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/39b3410202469dc821fd2f340a629eb0.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63120f5a57a8e0c4296b9045fd7ef797',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/2d888509c382cbff7c2f2bf58232b26b.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '824874322f016992d5e6ad43544c7852',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/23463141c7c0b30c110b28db2e5ceb50.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4859a3880f382e246464731a90d9ecf',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/a2f86bf6a72bded7d7046d0d5e7f1dd1.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c392871e288c2e75b77e16f671da0ba6',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/d77eb10470821b7e8a4a9c15854b2bc4.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c62c8afa2add29dcbf61f4f6843232a',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/0f830bcf6a81351e16e12e55e20467b5.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '189abe33c45dcf9b89d700d5de004b82',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/1c14673ead46c4140e14481a006a1d26.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b41446db5605816677cf0a83dc6de3b7',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/cfcbce738664e98634c11849ca0d45aa.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '366bce1cc97de96620ee70f644bb8dbe',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/73d7ff927147dd8ffa584198c8996537.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c49e5e98778a8f266e2a40f8383ca02',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/eb2f960871c033ed22e7504e75af9a43.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5efbda8c7a43d292ad22ac83cb7f50e0',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/1f7d0c9115d8409388a9517132555854.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2450946932a11412883a7cb0961f8c88',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/a20c8433ed24c2270e612247d790aa3a.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1105d1696a008f4b656342a503adf82f',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/623509ed7fa53e10576f871669dc9f38.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ba8ad35ab16b635b5a42bc58dd5537f',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/d458854ea06f511d12edb035760ea874.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8ac0dd779ad0e2052c848f903d969d7',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/11e1536c869279d2a30a54fa262194d8.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b14fefd36365be76a26b9b76cb48257f',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/729e7a75b6ee963a2bd989ef50dfaf60.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a253c22d58414f5a74dc759538a49d8a',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/3131ef87acfee1aa556d67a9a59cba02.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58b9921fd5c8fd1beb13fddb2274a610',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/835651ee734cd4ee9a1f432959ce92d3.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63c039a1540d8af6dc10e658e6978ebe',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/d49c00b0125bbe6e4376989081cd92d5.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66726f2823256b559a412c9b114d5637',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/a86ad071f39f3faaba7f65868642704c.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04140335d6b8de10e532c3a57e0bcba2',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/996be0f051cc309e42ae07ab3a79a7d9.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3f4360e8b95497af22bf45a033b8056',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/72946e69a066394ebeb95fc910da0175.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3512c8a8e9428f49ed1aa2fcafe2eef4',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/616f186db2ae9f58779b7ce0946bdf44.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a333155616399f802ee65f955685ebc3',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/54fe4d97da060f22d224d625b20de618.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec202926c5505927b03bb1efc81c7656',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/662a222a27cdf63cc1ed7598882e7dda.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab583bcdbc89b8649d4d66559e89d3f5',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/580ecb7cee07dc92fe39ff8323abf69c.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a960f8e2086e3038d1ae518c0f18312',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/cd2d69716eb6a8fb83e0a4473c75e2b9.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d45684268b19e5d4b3a2b5adca83128',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/9e1cb129fc0f464938f3fc2655075a2b.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3165139b3f0d1033370d7ed22bd501b2',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/f6fe801b3203d6c1de8caef1e164ad0c.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95da75b384964eba5735e13156447f27',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/5bb26fe46787d23f8c627f036be0c335.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bab8fdc4bc3876dc0749caa44320a1a',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/e7569f42625576fa99e7241f8bff170f.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4db669a47a64756e4543edf0e234402',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/d849bbbd06db60f19ac5ac6dbc2d6b8a.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccdc9a0b42472baa0e2433bf5e24733f',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/b4bba95d29e2e0c065411a625cc7425d.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68e37b865daa34d2bb05701d52b54603',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/474e955c9c6e3a5c3dee9baba00123bf.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af6582a40c0abde931bde745440edd3f',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/8d2bd8b688e4ab7b1b21f0bdc2286edf.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '458bc462d43d33b7c153c46b1f66ca8b',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/8aa13970fc38e8380f2bb38f240825e9.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8386c9aec63ce8abcf5d1521484989a',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/e808f0a86d51f67a71992329062b86b7.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec393b86981275ceb996a98824365f88',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/5ad8d9ad5a7735618dfe0e30469c3a95.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6f2b3affe3bdd17fe4342b985950a9d',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/553e3a049edf8e30f4d3072d54bbd451.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89097eb402ea3d28af2147274f92a409',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/ea54e5450bce23db8808ed17934614da.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0587447889470152edc2f51a7e51426f',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/4618ca4070e8bec197432b0fe4198f10.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6b21cf677002182869b8fbc0d01f76d',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/9992e1eb88143d766d68d5e958b35be2.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c006c07ce54c05238709868ff5de63f',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/5108c5bd7163ebfc1f72941744343345.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df79292bb2f8c32b655bb2e238876bb4',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/d33a062b5c937263a5edc6927000b137.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c532a2446b7989c796bd2ca26c11a536',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/7e9b85ddd29bf592fb5657530416d58e.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e763166504aa798ba42c4e8d58cc442a',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/58c6cd1a02a56481a0b2a5946a9639e0.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a768e1d3f015db02900c257aeb882d5',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/747675f43c79dc2b27e3f0460e139ae0.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '036b43aeeca17a57edf416a433ab13ad',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/9316099a123ca1f30e43b665e102bbf8.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f4c64f3b94468dc4fcfbcd567d0fac2',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/ebedd716b32b668cf3539c5d3d0bd302.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d144c058dca9fe762b4c7e3252e1252',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/6da156f25d5c230026518702c131df9c.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '711e2835c0f09dd19af3cf1d260d3f2b',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/a48fc123f8f9ee97962a4e5d9ac387ce.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a733653f968e2a4d4f368eb7ca4bbf60',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/b60927a0bdcd40a3af05b188161adec0.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '9880a449ca7771c973572eb3b891e37d',
      'native_key' => NULL,
      'filename' => 'modUserGroup/b5010aa95f0b9d2c50370c333626310e.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '74590d7be3894905af88376b674e133c',
      'native_key' => NULL,
      'filename' => 'modUserGroup/e6dc0323e303dc5611303fc4e11397a7.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ceb702013a5f2f48689d39d1af22f97c',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/6552900cba21f19627330dbfce57b379.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7ba5c9a22545b34201113e5d1c2e7f5',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/7345c2c0b712213d4fd34f092b87ced2.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bfb35054e46c5e912478d3d21cd937e',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/fbf7eec3d08d5553e794a35e85050917.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9a284e97e9f9ccbe05be78c1ba2b746',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/5261e41f9f775b41acd180e3e7360fe9.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c564c6b211be2c218f143ee5b859167',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/6bdfd286fedc221afa86aa11aec41d04.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f87f992f3e8c85fd3f6d7d67062ce320',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/6ce5774900ac2d8614289dced9498c34.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '914da9c3ae7d1d32dee0c5696116e19a',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/cc25d4b94d9b431fbef5fa9f7e9c90a0.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87306594216e978460617e583e0bfe53',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/c7d27b04f269c8b6f2be0a591c2f525d.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a83d539baaf9fa1d01e817c887fdba3',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/68635c6990decaba2d6aa75f352e8b94.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e617d4c804a05a8fdeee1b820ba3db32',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/7351a8ec176551dd4937ad9651e2f047.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3327fea25d2b6a8dbca3b4cc036964cd',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/e69fb6bb925a1600d8b8fefce1049e38.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d143cc2db43e8a9f5b734e1b2150e6c',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/247aabe0740ef4391e94329cd5a6adb2.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8abb7a236c755867a0a8d67496876dd',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/bb4d90b37a226f4f017f2d7b4e1de75f.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1cf8b39031454ae9dfb0946de220450',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/6e5184430f1e5d7fa8eb95ef313dbeae.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd576260dbff792ba8e3b48c1e63cbbe3',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/0d31f784407ca9597804bec2525b1c42.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a17909e636562ea11fbb9a21c5a7a77',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/fbb5b288a5489b2af52b50911bfe106e.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dff6364dd09ad596cf73b5ca8314e12c',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/5293669fcd6154e1fe4e8c19f7c5cee8.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f51086b3bc317e83fb9866014bb46dbf',
      'native_key' => 'discuss',
      'filename' => 'modMenu/53b72816a41848db6f314a756b83e5fc.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
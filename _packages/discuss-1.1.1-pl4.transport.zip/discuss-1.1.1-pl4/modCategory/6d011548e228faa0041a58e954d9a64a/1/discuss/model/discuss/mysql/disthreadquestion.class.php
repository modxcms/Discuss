<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disthreadquestion.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disThreadQuestion_mysql extends disThreadQuestion {}
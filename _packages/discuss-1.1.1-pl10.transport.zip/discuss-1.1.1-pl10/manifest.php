<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl10/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2e28e440fa4815886882492a0511dfb9',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/4d22d37e85375ad4e132ad294a19b042.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0f457e0a9878a71b813e0099367ea26d',
      'native_key' => 1,
      'filename' => 'modCategory/b5d5d42b6bfcd76631ada1aca306ef4c.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e9c5f9ac8248e6063422f6751fd99b89',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/0a2a96f45b5a1a83c27e9714676fdde0.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0f28a572bb0cec44303a8798044ea70f',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/d4df734757fce66021994cd2398b7960.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'aafc78598ecae56398b94887cb42554c',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/9835c216e95f0acc642020f90d0bbece.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '62b87a563ac60d557579b157f6f00188',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3c60905cf1fc2989b15d988d67a62406.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edc269a768bc616a10cebf7c66de790e',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/5e21f4ac78c99efaa091cace63ce81ea.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cc96e84f72c6fe791ce0d89918ad3a1',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/df1fb3c8cde0e0abd8e2a53c6574eed0.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eda1e4877a8d8d00dc5d62b167fc0188',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/6c881854edfaf03e473f4bf2cfbc2524.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96cb5156de091c29a00a6376a376ebc6',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/ad03df53c0ed4b1c8f60e9a907c7b777.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8654a3a2dc3efaa6ae863a66742346c',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/4487d21f8ae8fcfa964e43f8b3c2b548.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1081d01d37f143f3453ae4aae8da0472',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/c679aa2485ee1ec531fe4fb8f1e11a42.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '764cbb690f296d3867c847485dfe7c95',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/d05db958549d6d05208783f21e8035f2.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b350fb083237490ff8468a1f7b15a43',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/70e697f3c7fe293e2db131f82dd88c76.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4baf2c91afa602449f650de7fc8b8782',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/8e977818c9dbe7ecc47c83ebc32f30b1.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '102c98bc4c712fe53954185851239204',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/dd4a1a11a03533bcc08602ba4c06b5c9.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df55df2d567d8c9b55a70dfce61b5df1',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/57e269652f77cc6a9cf664b3a6359bd6.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d8741a088c91363afa4c29db440db7a',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/f03c8aa973ef099618a46027fca3782b.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a5b555ff1853013ee34e5e59cd30c33',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/d511c2e0deed4ebe14370749254c2b98.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33b6c9affb64d819fe21dec902b3bd3a',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/f1251d881b713923206327957a62aacf.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b79afeed3a476fabdb631d7aed379e33',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/b19350e9e59c58a062381ecc4b18552a.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d67978c12a154f89e245c538c28525a',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/13475c18a2ff8a8065ea5bba367c2f99.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3909be53155621c7192efdec4fa152e4',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/11817d149332298d5ede27c2ac78029b.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e07eaadeab3aa16226880d97bbd7a29',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/4a86088b9abc65212f7279a800232975.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '818f0d79bc8fff4674edb3ee7f39e986',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/a79686f3480c3c2efd2c895a84d03bc6.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9c5c17152dd7e984691acc91fcb1ec5',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/945f6f6e72ae0ee821e164a99a674ce8.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3b28f7dc77490a51536c23906c5fbfa',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/16c22dcb53dabf045b61b53d87d6645f.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '744b987358ac298768b6b2c4795e31cc',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/3d45e5be45128afbb490f8ff987a673c.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4df2baadd0c8fbcd1f7e0cca379aa16f',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/809d2e693e03c5080da5dc01bd7da7e3.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efe5b263ad1353ca24df715446b8995f',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/513aae55867e6a73ab7376b934648fa0.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ace412a752b777a6bd807faca41f05a5',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/5230c78253d2c2e119afac297db43afb.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a6d94ffccf5f031c7ad18d98d0f101f',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/87d33d8d5755a469973ae9281c97cbb0.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6081a3b27d9a327d4b5ef02d53778e6',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/0bebd81d8cfb0b42b1f35c50af4f5631.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11ae2b9762ff22831105a4ef40990d52',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/0fb1a0bc907e7a4e9fcfc5c6a2aa4796.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a972302609dc45e3f5a39f6eef415027',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/b4b6943b7bcf777bad1ae7fe85231079.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ede05f8dedd79b942c4d50ac58fb8d2',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/d019b714c29759096def16ed3becdf7c.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b8200fd3005396d136fbe9c4956f325',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/bf637dc7c65d3e728be6b43bf1abbe7d.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bca70d2e6abb3aaf5e89a554e673accd',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/ce1fe1de41d2f6cd5b99ed2c74245247.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '487914ded4deac65d52726326e68eeb2',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/851f2531f906530c9e92b3a1d24d7c33.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f93594622c1dd9e93f43952bce66b9e',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/077f4a0de1927b592b86b5d89909b5f5.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d45f1b2bff0b17b8290d40cfbc11620',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/e2cd5d567f013e479c7f20b19845f285.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2798bc34d2d989233399ead0748f84a4',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/7daa41795fbdba3343887900c1ba8302.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f84d0eac802ae9e2fa8eb175cb4e995',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/994f0dc884c0f279276493beaa55e006.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3837e5e2fd1fa1c4a937b46af5fa07c7',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/4634b56abfa64511d257336680734d55.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b50d179685b080e4906891f5fd4f6a9',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/762d2120f8444d3550501a572aa01f38.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03eec2e4f2c03c56a81c36b78886d69e',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/a0a9382ba2c5111a7239d7289c54846d.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70c2259b7a835ac9e70631a8e54d8aa4',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/84dbaa380259bb9149d41811fdff0592.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f5f848cd3681785bddc64e417471cd1',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/085aa7385187a7838ead6435f15d7492.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a12a434c132a1b57b768df418b50848a',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/990d621cccb39fc6430a432ba7e83678.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3d0df3089bd76226316c53965ecbe1d',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/4879bf066a592c8adf313c30f23eadcc.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54e1cdeb9edae7e37365430bc6531902',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/93cc55d5b19cfb8eb76fe66d6ab6f9da.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c94eba2b5ebbdb8da613fb575ff04d5e',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/f448efb185f88765060f2e79334f08b8.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '490b3901b9b845e7a11fbd20c7a5c9fb',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/380876183da9457210b2d633c63ba0ce.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8224e324e6316f8743920934f7abe04d',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/926cd39858fcb1dfadbca4e5dbc135e1.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7dd1e1da5db51531a96506ea51f1525',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/4b5f2d5b7eccf95f8c72e8d98bd6c02b.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2d8613e813282e64a7a2b004869a777',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/4d41abb211029abef782af3f7b0eded0.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d848b090b8b5f6f2d6bc59695fd5636',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/85221927ed050289fbc4d78804ae9562.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc80779ad2399411f773f01e8fb23c3d',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/ee94a9ec0b9b76e5f6c354168b7fe733.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '770c57376f5190bc4d60c630db8bee15',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/035809220b40635366acd56319bc7710.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df26f682b581570bb7e09574c11ca779',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/bb4af37083c8db6a2b29c453122b067c.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '106629b975d1960cddccb5524769f1a0',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/216ab5de1a808632866b28f970f08e58.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47eeee1d1ed5cf6fbfb4bfd589c8eabd',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/c250adae4a6bfe299ff6a94e082d23cf.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d1728cb9b5a4e4cb9ac2f95bdeed944',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/cfe568501ceb1d03a216fee51064d2a8.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca45d54d152fcd87c7664d00a9bd701e',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/6ada079cd3287ea2fb05ff7bf5cc7bd0.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cb8819bed1746fad6593fbbdf62d128',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/15ffadf2dba89f8c89c74668ce809322.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20ccf99491b21f7863cb28359ae31f63',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/559b936e538298af6823e2e154fa05c8.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd660ef98e3df8fee7cfe91aacfe2a1f0',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/3585f9567354100ca42c7806e6dba27a.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b63e6f9352c55b4fba13463c68fef32',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/0fedfe438f7d97639bcca249f8b7774a.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe152f053357dcaa0bcdc343e6579bef',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/2f8c296e55bd92beae7a97b4b279aa27.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ae75c5783598f2cb4fe8b9381a09882',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/968d5556c0cadd0c7931f8ab75267737.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a10592a4142498a97ca309df75d00b7',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/2cea0217ca563a8a9823bfdc34384ae5.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '884fb63f312f9e887f93fe56b6a13796',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/4c55b2f7fd4acaab9a27e2c67d5bf885.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c24a5c6a007a60a6642b4edbbc861cf9',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/1ec21795489d60b68e0465da95ca4dff.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06af110666599a2c1540da888b52e76c',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/4bec2cc44155cb5b0be09a669d15a10a.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6475a83fc8ea3a7dcc286c66d4ba0933',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/362d195393253b0fc9cdba4e594123f3.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ef2d6344b10bbd284afd25a33eed42f',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/7a787dc6f46246520bd45d4aa5dc8bf6.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b06cfbcd13918135bd5d4534f545b70',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/ad1fc73f8fc1b75edf098419581c4764.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bb1764a6f634eaca173a2de4b66f2fa',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/f053626dd751f6a7442a70d09c73a4b9.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b1060257ac63d78f7272ecb5e59e32d',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/d6438cfffe5cb43b18ae7f00fc20a0b9.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ba3190c8e706c1b32119184b54c3e38',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/acc7a7f3ad24b494ac04cbf6eb4e5534.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f63be286fdb5ec7da19609291e6931f0',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/6c9f41471335852c0494ab310ad594a2.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da46feed7259701e24a3a44651e0afba',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/4b045a3fece70fb6860889902e0b83fb.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d3ada13da625e0512451ba2c02a7c1f',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/8b30ae94cf644b7198318951310693e3.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f38d24c008bab0b9093b4da2d8631dc1',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/053699360292a2dc2b7bd05fb77acdd7.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '80cb209353610266cfaf22366e64cfc5',
      'native_key' => NULL,
      'filename' => 'modUserGroup/efd12b28c13fcd737fd5bdec1cba1877.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '9dfafc85aecf01a267e3f42549e828e6',
      'native_key' => NULL,
      'filename' => 'modUserGroup/58732f59c41634012d9a9dc3c5ad54f2.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8ff55360ec56bd02056d3ad32966c56',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/67dc84fefa08a692cd38960ecaa21f2f.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a27ef3f782bc4439817f39479ac4273',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/316a844e710849e84fba0043c853a89f.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec8547a3223eca0e5f2afc5dd7ac24fd',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/dc678aff22c0cf9f6f3d805f198582e6.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a18737074fcc859d4147028498c112a',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/0aa2d55f6c533cd4acc2996ef4b5dc5e.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00caac0756a1e24e2e8e3a637ee8c7a0',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/9765bb7823f0895f91fda86a1424c293.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4e067c5b9561623c15ed6b482842fa8',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/300dfb0ea5f4d6806b3d71aecfd9a609.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b51d5b9d20312ac214dbfe56adcd9c20',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/f6995191f83a980cea09a13b151f373c.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2764b54b284f4cadba28013fa6f80de',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/7434b75ad6479bf899456660d93424b5.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbc1eeaf506d30acc458327307ae2bed',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/6d6cce808047d10fe07a4986bce1ca97.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9ecabbb321f5093a654ed1f18a80989',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/ded0b3d4bd7aee22fc92b77c1f5271ef.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39f3514163c4e3be2a3a7a1df20eb1cf',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/1165bcaad7db0d951c7badf800ee07f3.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0d1a01cc19f4b913b9014c3203adaaa',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/f1496beb08962af71e6467b7f6ecde76.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb07f73193eecd2e3aa9f0060dc0ee58',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/10fb838fc554b58bf4e9c22c5b2f8bb9.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99cba710fa569ef2e9576e33aba9089d',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/45a40939204489d55be8a27b86aafec0.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0d13a1ca79243059d54da987d5aa11a',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/ecf5a15458a9df357eaf3733b366c124.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a9deedb6f6215a956507a5639a42633',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/0e1566ccbf93cfea6580be022e461b0b.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6afc29668635e2b024eee33cf07fd99',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/e0e6ca3763fc13b342e2170ad6cddbc3.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '187cf44cde928d1b31c084c0a3dd2ade',
      'native_key' => 'discuss',
      'filename' => 'modMenu/97abc1da7c2de8fb2de63c1ea9cd395d.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
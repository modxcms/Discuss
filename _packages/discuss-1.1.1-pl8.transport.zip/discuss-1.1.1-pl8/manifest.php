<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl8/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '038e2eca886d580266c9bfc05bec2fe1',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/d45570b039322240579dbb87a61c1dee.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ac8ac26176ecd05ecf5d5c1df3e58962',
      'native_key' => 1,
      'filename' => 'modCategory/99cdb1b5b68262badf7e7fa3a7ddb0b0.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '83f33ead3e7ae7355af1257ab6da13e8',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/865a958befd2ee20061b0d8f27bdef3d.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bcd77ba28fa020d782b13d7fb42ab18a',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/d8733e5c7b54a11434c23d2fdfe697f4.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '956d6d2985738ec6c815740bc85463e0',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/8230de673e81288566da46ff6dc5e20d.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1b3176d2307d242a3d36f88bf0a3bf14',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cacc5056f604a67bf8a7ec8b8b998b1f.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b68c86b14c8597805e009a12e04bce1',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/02fb0f768bcc384573e0f79ee7371f64.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5693378a7d5cee46211ed2fee44c8237',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/8f745b663bfdce99b14f043cb4e0b3a2.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad5ca003dfbcb53df989bfbecf42f0ac',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/723896f30b8a563c9398c13aa78b2a21.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa92c7e38791957758ae567f9a76f1d6',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/099b7dd876fd831be94aa6014da3ef7b.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c84c65dd5d7006d4960f5de2d74fee7',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/21fab7083e05ea0fac53cd892e183b9e.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9bd570ec3547f10f297ecb547f623ca',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/c3ea967683b4dbdd9e7ebbffc7bd1cc8.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f3354f411534a1aaa70b753147883cf',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/dac96774648ea12ec80f50ff5314bc25.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b0c08ad568ea76dedbdf8143562c656',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/4014351bfa068ab58c614a9a1cad68be.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75801392831005d086fa30f9391b28c7',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/e278feda98c1bb4eb08e6cf0ac4002d4.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fda2fce34a48c20ba113231dfd2e72a',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/50873421d5df8c93c39989fa701c8825.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4532250adf6b811969f9691f868ccc6',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/c1a17241789b69552e1b0696b9622e26.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1bff595477293e1fae6c068255df93e',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/d3dda9da79427c699a6011d8ccb0e55c.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ade9e2cb48de1ceae85469667609450',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/99e72d9a7b2bd07a57d1eb54517d91a8.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f891606b59a43f2b6c32589f19a953e',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/47a182af4cf4e9dec8744176ff132f82.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f01f1a5c5587b7c0832fed2d2ddb10c',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/97d3247af23daf04769527717c5f9bef.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcdc9f3471ef696ee03f20d6524c5b0e',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/0ea74ba471308bc6ea22bcb9b1a32f19.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19d0f4667ef69abd38a2237eee54429e',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/70ed9a0ded82958046ed7296faad5fde.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c6cd2fb743fcf7c16c448ec69b4b0aa',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/4e08a2628b40a675988deefdad567c69.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c999a048b3cccaf4fefc4fabfcb4d485',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/8e74d1aca49a5e17b4570d8133f5e964.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1b04d3afb87ecdc730d62a585264c7a',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/c0b462b18364d53baaf4755eca69a92b.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5fe42c52546006a82457d7118c4e34e',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/0fa4460cfe0647f39ab8e03bff5336e0.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cea63d8f4912335a641349d1d88c02a',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/61bf214038271f524163000a7b4f2042.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0df2470690c1eb551ca7ea0999ae97c5',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/4e19a30c34b6e49887fb312bf92bd603.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dcce0c201b16b8f1e7941ad925426bc',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/ade0023222091c59d83ea2dbdbbcfffd.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a85d5f32794176a2724b5147979c3df9',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/99439046131f0786945c8acc540f9bc2.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b26a15f7b22f6c7d8e84eae798b29aa5',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/0cff5e9d3a59a1858479e15ed63e6135.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6549fe1e632b931323bf0abbe733ed2a',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/844f51a0e698d6e55ffb88797c58cb91.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7abbbe7f2baa17de900ac07f8536ca3',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/d4914f338fdc3a0fbca2c2ba23655e98.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f583b7fbc970d9c66d2c360e4607120d',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/6f2cfa903542145cc37baf39686dfbfb.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a21da716f546ac0f9528162a7a618800',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/0cebdb95b6a8171c546c9c1775888bd9.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bd6a09068aaa1b16038ea6919ffd116',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/2da50225c1dc0c802b71a39a25367f04.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91e0983e51bf24c50bcad41c8e7622af',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/8607ce5c2d3b06ab93daedaa2f374b96.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4b2b93428ed80a05b8bb47ac9a38493',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/7654cdcc24803c0bfc8b1aa2210b976e.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a433da337aef52b2f5507461655ad14',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/af2f232db75b96baeb4dc64fe4f25d4c.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c07db07aeb7578bf18a3cd86cf4c8006',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/1db7142f14ca734f4adcff354b15ea06.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70624ae4656207d4e225ec8681359ac9',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/1c811ae22bbd5735e0ce0143e6127635.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b9fd3e514e445d04b061909cc74b50e',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/ef0d39157dd6013421c888be8e8cadab.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78006d22aabf9db20e3ba405925b687d',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/fbc775b7da48a3ae9ecf1aeab1413276.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1966980892927585b2a91a7767fcd31c',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/1ae2d35e390f9d2ad34e840d238e4cd6.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09d7372c42dc2a78b104285d49c5a4bf',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/abc0bb99f9b81193174922999949ac30.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e73c8833391ae90d20a604770dd8940c',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/ce12b0b5ade5e5e1ba3845a7f1a332f4.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdaac3de76cca520846c575f8bde040c',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/224d06ccd5543b83c756a60982d095d1.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0415749258fa9ad3562a786b06ec42e8',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/b642e24af399b2c7b6e402556d62d1c6.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a74b732890ad219a57b88d67281ffd0b',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/858453018e2ce264873534041f212152.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a86756e510dcd554a4122e3c83023b5',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/75b5fb87cc5506d893ffe479b8c127a7.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d36374bb68fabc0ce6e1e1c463b4d0e',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/85b57edf68e77198c266a2fad699e094.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7afb3355762c9ccbd9fc8d8fea258e7',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/aa841bb541c2ba14a29830b4c8a5dedf.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23fc38527485d258e11ad7ed372ab739',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/2f98a5f670a804bc6332c39d38b19a03.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7fdab4d6b357871876c3a9382afafd1',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/aae7bfae9118ee52c8b881e7552d8399.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a264e27fc1401b1811d0d2187cfeb3c5',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/1436c93aaa7b1c50d4702aa6a0e79a7e.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24bb5f97e6ddf2925b3b5a0f6e84db67',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/ccd2ca318a35762b69affa3366a7d824.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59c2f11318ecf64f152a8d70b1451634',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/ed31fb61050ae650331b72579fe4556e.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '894d8c3d4604a14725577356b689aa9d',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/5382947fa9c6d6abf9a992014f2f8f59.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5c8594dc7c8102d20014f497015ced5',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/ca4851a0042a545789869fea900fb785.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bacbc5c1b0961bd962e3c0e3d28ea7e',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/021b5da764296739665b8e119d9ab17b.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ed2a3b33dcbc4b72c055db294cb9c1b',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/9a1322bea53856c99e03dcf6712e5355.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dfcafc9b1053e5af77a2cc1075ce782',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/4074bb5fb53141a442160725fa3c5505.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ebb6587e264c7820d722efd8f07c602',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/88c1bacdefa786aacf6572d1636782e0.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c73fbe5960cb65f69c7800d576613de',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/2048177a100162a72ab8f01e153aae05.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52c94fecde8e233cf08c1f46084a8eb7',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/5a0425f5dd585666b0df9cad1fd0a468.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d78d4af8845f8e358a42b2588150a35',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/7ba5e3bca3211277bacf4d7f8cfbce0e.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79f3d3811a0f566947119fa05f26326a',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/3859e32a2e31b470a806f84df4c7c6a6.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9cbd75369df107625dc1c3b4afe17d5',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/def9b3ce9e7c5f1faaaa639d60f049ba.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f85ca7983110873a141838c6a9b10f58',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/07f642cbe1d313bde7436dacfeb56e98.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cfe08a19de8e4e004823e27491d0677',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/930d4b5215c28bebbb8fcf9e81e83beb.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de6fe064d922f5bcd58ab901dd7760f5',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/2b60527457690570c0c7c37534c4b09c.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e63e0479183f57571c0e5db79139e20b',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/89a2c549016ba986993e53630c69afec.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e95488f9fcac5c5b41c612bc15d9a4a8',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/bb651587178d90e50d8908d3abd8aa4d.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0c3ede929eeb4abd89e15f883bfe9d9',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/b00aa30f93a58ab929b6d96f4929d7ea.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f56973e18b712066f069d8da00681256',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/201309551a45448b4d8e21f999f3fc72.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25a630ded24232a802d1a9bbe0d1a0b2',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/4b9fa2f8c2a6f4f835d213f319cdea4f.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be3ce007ede0bdf0b9a5baf3251e37af',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/5dc6da207fc11d264d4d15a6aafe99a5.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb30e4fc0ba9153f40374abcd1acb442',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/4f2b103f2e7c00f107e5607896a9ad3d.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bef636036fa7074f1690c2ca8f0161d7',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/67ae2305d0091f1f133b024d1e8a96ea.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85056fa157de83f5e6a9054c7d275db7',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/a76b4a917ee7b6787e1cd5302218b991.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea8fdc4599713a0123c95bebe0b9094b',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/8a88fa2a0fa653b94f33bc608faa84de.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89edcf8af01e6552b954bf1566da9015',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/ed10bee6576e6f5182b1a749663bb006.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56852ec4b50f89d916a9814eb9ddfcdc',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/ca9c65f21b576276043425eaee94bdd1.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '547f25b73743b5dab3704d970e12228f',
      'native_key' => NULL,
      'filename' => 'modUserGroup/1857f2bbc381126b49a77cc21fabd5d2.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '9265dd124597cee098bcc2c01009ae7d',
      'native_key' => NULL,
      'filename' => 'modUserGroup/c9461858d93b1752ef698de68dac4910.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd8e3c885ad03f610a41d9712bd96523',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/648be7dde88d190cff8bca91e6afa902.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75f809c2d62b2c3b2eda08d038ee755d',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/422016b405ad23a1427c0a330598aa71.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf48f53e0ba49223f3d38aa00c677d4e',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/55480ad1d930bd85ce9df27b083996f6.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e322e8e127c539980921dfcdc67631b',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/ef392ce28ccce6fe52161b6a7a95b6b8.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38ceb4460404d5785c27f89f34117737',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/347aadde46ff963facd2013094e2aa2c.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8aa745c815fe364fce1a9f9c5f5f7f42',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/1def685516d7f54be7e13a0604b7bea9.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5658568debf520a009f91e07feb7ff3',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/64b4c42e02cc27e591f22113e269bd0e.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '883fc4b674e3f0dea96f18668d0745c7',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/f1e2295de30fe73478d41bdfd88247ea.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0de6fcd4a0ea5f55379fe616ebf31b4',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/cbb5f365f3ca2d48bb82e223a62c9c7b.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a12a451600ec3d904092d9d72e9840d',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/02d7d317bffa2f944a5675da55c7ca39.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9b020daedca1559deb052b01353e275',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/05ae705da246b364bbf7e779f8698b59.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a30ac41f5795f7f85399a9ef58c17f39',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/7258762f415c9c93ee4a0ff904d33327.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2750e3634c2f60267559963e0be1a7fa',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/c285d99051275e67d7151ef4cbb7b0c7.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd402164171ef15cd034790c23ef58c45',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/5de6f0282bc83b3ccb702f3b5934fb0a.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '549dfef6aa4052b1f64674dfb5ab3820',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/82de04ce17a6234d489d868f6e23cfb1.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d4b12a871d607232f7f7de2782f20b7',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/f036a6c5c4a4da7228f90cbff3495692.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0eccd935cf8694a8f51a070645c1c2a5',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/18823d6ad6248f95f469d50845e944ac.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2d6abb318c32f33f2f25b7b33eca3728',
      'native_key' => 'discuss',
      'filename' => 'modMenu/55c157e42cdb76de8cc2d205f681c295.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
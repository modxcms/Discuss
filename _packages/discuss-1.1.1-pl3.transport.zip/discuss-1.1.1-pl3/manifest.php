<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.1-pl3/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bf9a0fcfabc3b444b952845632a34974',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/7d90a0bfa0011cce8841b552977c6fca.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5da9c78f1ecc38a9325ffd1bdcf01214',
      'native_key' => 1,
      'filename' => 'modCategory/0bbdd6a778cd42f254fe5f1a5b96a0db.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4f052789867f2e9edcf84adb0dce4c9b',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/2bef5611d76b5c2d1b5c920f02fbf4a0.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '51fe877796efd47aa668285dc6e80548',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/92e3d75970130f764d7ee16d9a4cb47d.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4e81c23c150d3d75a58dacde9bc3ab59',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/dcb787193a0d0394c82a02b297187de3.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e9a31494de87eca6ce5a3e48ad6a2b6f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/98161629f85283d0705fce38eb4902c8.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5404151e9cf6fd7a1698f8acd8d9d56e',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/3d7773d847c1f2d45a33dcf0a0541931.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bf29564f632e46a562923d592f6ad62',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/5908f60ae76e261f0ab41406a04f15c4.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90e324bbbd7042f2c20d3838aafafca4',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/16102c4c8b8039f9b51d89b1f83439cd.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1813d4565619b902fd92e51faf41b85e',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/feab1d2af7130571b689ff23cae33472.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1c3ee2abf264e053cd8b1ec33b2623b',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/d0bbfc00c362e9c3ff129b7cd076f0c5.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '439e7b496345f09717fb4d4e5db9dc08',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/58c1c9b97a8525f7cc3604e192b18c28.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a282a51851c05d5c74976bd1552ad8c4',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/a1c1b517ad18d1756c2619981e824903.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b6979caaaa73357ce0090ba48536c14',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/7cd0bcc655ae576058761f77640fba9b.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '233651842f477e44484ceb78ae6a13ca',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/28ffaf84ee07a41f3de1fb21524d02b6.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9084c8166faf28bc0365e228dc35269e',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/9748c6b04f56d3f918fbb8176973efd2.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9867c41d9fafa4222e4fa5f9f1b58d85',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/baeb653edca847ca9e00f010dddecedf.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15409aca61a42b75a0ea96d86286dc11',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/947486a3a3e5f9a37ad1b64b25eb5ac0.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '893680e9903d95d174a635eb8004e6b2',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/0055a206b3d364646687e029e96a6b48.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e3d5a9d26156ebecddcc51e1e4341af',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/a847f90acd62a7bf10de663a86d72319.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6b8e64caec9354adfd1cb5e14c521fd',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/adadc6f0489dd85ded54b19c5f10b7b5.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec90c576aa384ea2d8ae9f3714da6ef2',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/1ec9e0bfd1a1923d35596cf61b79660e.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65371148d4a3d6c5f6ba0abbc948bb47',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/500bfc033b3ab5dc5aaa757a2f2eb4a2.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac7afd50a7aaa2d5b5c891fb50a73023',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/e1a15b73434e8cb50956215de60cc3a9.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad354730b7289fb56b9ca97883f45939',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/7af615314f53568275990f865a563f03.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b17cf4e88f24c039dba11be5102b2f6',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/1c0f069ff9bdbc1ed9ef25fdc81a6d7b.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d92cb37c101db23342b16fa35fe87a2',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/819fb2ea9eb93a26dbc516c14d16f8ea.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3c3d765dbc2c6495af3851dfb133582',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/96b4582c89d7242397ebf52b49645846.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '892208448966ef0d047db56002d74ec6',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/aec73d4c32411d3c5ab832c3d7218318.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c16d2c2719941aa975eb9f8158861ae',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/cd6061d4fe9ebf715aa055e64b0c0e97.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ae56963f5158bff97e8c40478bdfbc8',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/d85fc1a701d81902de69b25a3535a2cd.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2400179e571bf02a88b1331b14ceb54c',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/606f70ebd250bb6f9a1fe80838c8f48b.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a28e4bb111445b95fbd6d7df7ce8bf09',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/d89ae1ad6234cf36648658d5b1762da7.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98daba17c99304f88acc1a89129e9934',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/85a6b871cf4680574aa0c286a3342fe8.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93f07336b3bd979857db50ede231c3ce',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/2bd12f5a01833fca50a846ec6ea7719c.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '255dbcd3b39efb3a9be7c4e2a29780bc',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/bcd9207c9725e74c008338e683501828.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1139fdc59fe5e137161efe221fcdaf0d',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/43a4b5628c307709a3030c5a275c3e10.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b11f6175a7dd9f73ebdcdc4feba59bc9',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/10a9c0ee23bdb0bf8aa8b0feebf90279.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5badc60db388bbbc522430848a0c2915',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/86c12b044fa1d5da87a882d6c8a33175.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b476b2b7547febc8477c271ceacc4da4',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/2da4cd39d938938198f51cabf74fc36c.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ea2c8155e5cce714a4e63019192cd5c',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/3be455986e2df46d348003c6fce48592.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec1722ef140d5d2029ffcdf007d0feba',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/8bdeb41e1e06388ff59ccd4ebdeb1e71.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3229d04cfe8f077ae97fca226afc333',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/e85512ac0d9ed664ecb0da8703d639f0.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad63ae0253d1e92c7b7ee33e7772301d',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/6a2e69b3687a46ac63683cfcb314f691.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f0d91053bdd79c848a592317a90d22f',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/edd25539a5de5048d0323e7b1d88d6fb.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa28f13efbdcc387faf23670accb2c0b',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/219bf0dcdfc3ce449e05707068d0e75d.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4b5bdf3346dfeaa87a8c660110e67a2',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/a4905af476619b09dab7032d03e5b09c.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2761011e787e0833688a8991e8ab171e',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/17fa8d71d72d54930e09e8507dbb9033.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3134e77c983771a8012435abdcfd11c1',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/a4a01ae4847cd6e579a86184ff4efae2.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1d19b0f02dafce06ac9b25ab1b76bff',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/1dbb80ef4c6563b0f0f0a83c5efdd132.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fae178f0bd73ecf890bcf637ea15def',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/35851265d9a68107b7a521a5ad42f8d6.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'decb59eb3d3403062c895659d9ffe53c',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/9a01f2a4ef640eaaf1f4ebb6f11a0ea9.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '341fea40b275dcd70a006c51554fbd1f',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/bb2033099076dfceabace76f0f24c584.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86c39f9716c8cb6ebc92c2dbfe7ac23b',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/a1640269200362cbda477f489c086d2b.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a4e684f5e370f802dc1accb144a2d5a',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/961bb7962b7c076032f72d048bbfa807.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'becd1335d394bbae21da31d2e99faa4c',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/f019328a5c3599d27bcad430d7763f45.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37d857ea1191aafc94152fae090a1cc0',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/e4376a32c63bb6c3244d605973998e96.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a86e758184de55fc5235d86759b7d3d',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/b63e2ca6c1c0ae618eabed774e4e689a.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b70f411b8e53753f4199aace0eca0329',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/d179371db36948effa90dfbb300a2116.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '153fc2d00c439dc05d4e93c5ad107385',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/05504f669fc228ca069275cc50e24901.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd816bb4cdefdd828aa09873c85fa6e1c',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/59ec1f5933bcd559bf2ca185b2cacd4e.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d9170d31310f5aaf7dbf3408a04f497',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/8990462fd06334c3494713b069a6cb9f.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1657db70010f4f4c8e800a15802fe3b8',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/eba22391ca4296ea11a3c58d9dfff930.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87d9458c08e92fd655b74ea92ab5a4b4',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/69bd448dbb85bf18666f0a86c7e04be4.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aefabe8d47159c8a7a6d3faa6ee8a925',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/8680dc63a34c141d77d84c6b395fa27e.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c52caaa348ebe604b934781d1d86033',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/002ea71cc393a99b2783c02f16184745.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9368f1f4f3c1765acbcfd8fa2d55ff33',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/e0c0ed163e43c90ac7dcc55ef9436ae3.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ba9be49213770ca6e15bbdd630706dd',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/5ad5864093e4b79ed13868ac9c1cb6be.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ba89bc1d44b34c4bebe8da50c14d9fb',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/56a3dcc0eed4d8582418d3ad772fb36a.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08fc25115ee5fd94fe35dbb4f8934ef7',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/543cc2c18c0d8beb2be80027f32158f7.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9a092e765b9fddaca01dbd4ff917aa7',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/a8a098c5af254de9cd7b555f8e937897.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ad0b74a0303a861480646da9e7d70f5',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/dec8e588d6a9535bc832e25e9d03e9e8.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ad5fbd712a30adeafc9c70f3726f62d',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/2841df237269e073744755328d5aecec.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3563a9355da46548efc67b55042f70fc',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/cfddcd3f1392ec304589a51c9b8bdeb0.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54b6f981a0ff3a7a8ad26e848b53f185',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/afc39f3b537457baa55ba894844d571d.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07025056dc35e21d9670e8f959186eac',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/ba66aef6aca84d292c28abfd7da7b4ff.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c29b4917bf4623aaf121871e48dbbfef',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/79ac138272b94dcbfafc073c45349f56.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f52f86222d42e881b816e93d6aad2e70',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/b65f34094f9c6d847a838ae0a33d2b77.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69eaa47cbb4314aa74fe0b04dc65b9fd',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/2354f9a7f6ee08691b95773a82fa7979.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6e610b1cbae90747924fb74776e1d45',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/5ee14bd5a6491121b2c6cdc98b522b83.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ec6d53d1a8b147a447fb045c40b88cf',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/9b003c9ea93d83df23a078c0a5bd383a.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9c7b6ee7e709ec1109e1c87a9f8880b',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/0b1609e03d47f6bf222259587f8751a0.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0217a0b5182dce4a8744c8e637c982e7',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/f665ba9eccb6b300abd92224fac391eb.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cab1ef3ee9f9af78e6c7874a7379cc8',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/b62036bb0cac491f6afb0a1c28d4ecf3.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '76bc126521cab1905fd7b8cfac624a8b',
      'native_key' => NULL,
      'filename' => 'modUserGroup/dc70a079cc6403d56ebb214d7707bff2.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '801ae66773d96c0891498a2106d139a4',
      'native_key' => NULL,
      'filename' => 'modUserGroup/1ed8795957116bc1f90ef27838c551f5.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d40e71b17a140e1a67961c20448cd9c',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/a995917320e88951f097da008de6f8cc.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db35792e79466db173e1ff9fb644b620',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/2ef68957912dea4f4af6131e2640f653.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46777e7686498c5f6f4d42b456d17137',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/93ad57c3dc70f1f9c5bbd87e63821eb0.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed786b299d2c065557d379497a031d8d',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/871b50be8743a2dc356a1116a887f003.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '298c4ee73ac9432709b54c4200bdb4b9',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/5f1e5f4ba08282bc8f90322be5843a7a.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a698fcd0cec5cf4df5657f8c44c58165',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/a90456f907742246a5bd6927e0985078.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf6b4b7f747f8dfdb26b5bc8c4a3ed8d',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/ec555c064e2281007af6ccfbda134a31.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '861ed2c5948348579b7210d71d3374dd',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/223200f41f50201815a2b8e2a2108dec.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbc50eb5b88561db8f6a0225525bb769',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/01f31fa998daa9babcda004df62afacb.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b2a14b031a5a13e94ae131f527016f0',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/9a2b19bc65a57509d7573ecd6443a595.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39eae23baab072a70d94088735bea1a9',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/1eb1265fa8c3149f42a33d74b2c14bb3.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93dcc6eea981903db3ee346120cfc75f',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/96eff8427841c4e7d5def44a819c038a.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e29294924744f60bec6719ed177ddab',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/557924eb92c7ddc5c501f712039fff76.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a751ee3c4715d4a8c494ab998023656',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/ad76c10bd534da8c444ae9e76997111f.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7fbd3fe06738671f51f7fd107d71c30',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/9b7adf40977e3f6770b585d22f0c848e.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a878ff9e59df36b23ffe09d4902c726b',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/067e5b378a4fef5d40a6f4a680b7d31c.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '805af435b5a2cdc086f3910c5ccb5449',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/33311b291662ad1aff5a0ce36950713e.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2ae9e8120f2a570723314db6d1d6a267',
      'native_key' => 'discuss',
      'filename' => 'modMenu/4eced209bb4d41c09283bdce754f62ad.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);
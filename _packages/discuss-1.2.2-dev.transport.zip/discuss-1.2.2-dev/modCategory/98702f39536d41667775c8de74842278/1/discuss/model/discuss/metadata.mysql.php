<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'disBoard',
    1 => 'disBoardUserGroup',
    2 => 'disCategory',
    3 => 'disModerator',
    4 => 'disThread',
    5 => 'disThreadRead',
    6 => 'disThreadParticipant',
    7 => 'disPost',
    8 => 'disPostAttachment',
    9 => 'disUserFriend',
    10 => 'disUserGroupProfile',
    11 => 'disUser',
    12 => 'disUserModerated',
    13 => 'disUserNotification',
    14 => 'disForumActivity',
    15 => 'disLogActivity',
  ),
  'xPDOObject' => 
  array (
    0 => 'disBoardClosure',
    1 => 'disThreadUser',
    2 => 'disPostClosure',
    3 => 'disReservedUsername',
    4 => 'disSession',
  ),
  'disThread' => 
  array (
    0 => 'disThreadDiscussion',
    1 => 'disThreadQuestion',
  ),
);
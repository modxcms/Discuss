<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disusergroupprofile.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disUserGroupProfile_mysql extends disUserGroupProfile {}
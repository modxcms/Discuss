<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disthreaduser.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disThreadUser_mysql extends disThreadUser {}
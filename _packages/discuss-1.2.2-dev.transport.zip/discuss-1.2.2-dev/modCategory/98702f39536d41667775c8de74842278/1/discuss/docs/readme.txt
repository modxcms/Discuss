--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

Version: 1.2.1-pl
Since : July 23rd, 2013
Author: Petri Rautiainen <the_dunnock@outlook.com>

A native, threaded forum solution for MODx Revolution.

This is first pl release.

Feel free to suggest ideas/improvements/bugs on the forums http://forums.modx.com/board/?board=27
Also, please see the tracker for open feature/bug reports : http://tracker.modx.com/projects/discuss
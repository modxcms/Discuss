<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

Version: 1.2.1-pl
Since : July 23rd, 2013
Author: Petri Rautiainen <the_dunnock@outlook.com>

A native, threaded forum solution for MODx Revolution.

This is first pl release.

Feel free to suggest ideas/improvements/bugs on the forums http://forums.modx.com/board/?board=27
Also, please see the tracker for open feature/bug reports : http://tracker.modx.com/projects/discuss',
    'changelog' => 'Changelog for Discuss.

Discuss 1.2.1, July 23, 2013
====================================
- Merged pull requests from Evengard : https://github.com/modxcms/Discuss/pull/2 and https://github.com/modxcms/Discuss/pull/3
-- Discuss does not require furls
-- Discuss furls work without extra rewrite rules in server config
- Merged pull request from Eldanilo : https://github.com/modxcms/Discuss/pull/6
-- Fixes variety of bugs and inconsistencies
- Merged pull request from Chistiansteel : https://github.com/modxcms/Discuss/pull/9
-- Url aliases are generated via modResource transliterate class
- #9700 Thread removal via manager fixed
- #9805 Drag \'n Drop boards and categories fixed in manager
- #9804 Category field automatically set to correct category in manager when creating board
- #9427 Feed fixed - courtesy Eldanilo
- #9883 Ignore boards sorting and checkboxes fixed

Discuss 1.2, July 11, 2013
====================================
- Fix SQL Performance issues; new indexes and improved SQL queries
- New lexicon entries for default theme that had fixed English sentences
- Sphinx search server implemented for search
- #9525 Unread replies and unread posts are now accurate
- #9882 SQL Search improved and has fixes
- #9882 Private Message count refreshes correctly
- #9393 Marking all read should not cause server stalls anymore
- #9525 Partially related to 9882 and is also fixed

====================================

- Add ability to bypass stripping remaining bbcode in disPost.getContent
- Fix viewing stats due to changed session place in earlier version.
- Improve performance of disSession GC
- Get rid of MODX.com analytics code in default theme.
- Fix XSS in the search controller (date_start, date_end).
- Fix XSS in the page variable.
- Increase size of disPost.message field to mediumtext.
- Merge in various updates primarily related to search and solr.

Discuss 1.1.1, December 28, 2012
====================================
- #9350 Add missing javascript link for $lAB in default theme
- #9349 Fix errors in build

Discuss 1.1.0, December 24, 2012
====================================
- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.2.2-dev/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8b38ae575afefe87b1394a7909c7037e',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/bfbe907e2434049ac75f44017d9dc6da.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '711bc71e3aa2ef513e9e1943547b7cfa',
      'native_key' => 1,
      'filename' => 'modCategory/98702f39536d41667775c8de74842278.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6bd9eb3e1e962ab830e68f47998e1e11',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/fb137ac49fa107f72418ff89c19ab029.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '47442452d8bed1ebee4e2b05961343a4',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/20735de5336c3b7c04b78487ad8f7ff5.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '405f8cf39a034c9d856881ba578ab06a',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/b7a89c769f2e405cef421101afa2d638.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '736f6b2ad8224044f7aa8311623f24e5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c733c1462dfb6539e0d0b4acc6734703.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21b92e8b2b1f71e6e4835f189eaebe52',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/fbde5354b8ef29c8482ad2b8af4d5030.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '356c9f497b0a4b297f026b684abeec44',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/4212eb35299e20c6a3661428df913e9e.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da75590bc2ad23a60f1f9b2ec5f4dd62',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/1ecac85e286f9ea0c9849292ab503c17.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0d68cfd65e96d4d8b17104bf7bc9ae6',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/3806e44791eadc120911ffce43f32011.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b77f57047365a311c85728aec59d71d',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/4520e5a0f902257bfe8a6e1e6038c9c2.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74c5ff0bfd57782965ad3b3c0620a598',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/45b01518bd3fc2d7da3abb1a546c9da2.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb9c3763a254dfe5848a2379b2632ae5',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/94484fb74ff3da0f0f6f6883d9662eb3.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f02f114ffa5d5a788d7adead975cbe0',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/6472f2c9b1d23bb23f6fb6f11242c3e0.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53ae63e5cdb816395db6bb77998f70a5',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/0d2c082148ec1e9fef252577ef18d409.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '245024a33961fd86e86e66d039a81ee1',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/3649c5731c2b8a6c9ad70d861264658b.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82eb38540d795d1a25eb40196f44a8d2',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/f9235d09fac5970280fc42b48fb22523.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b91c3cf95e9b51027d6ed33dfe1b22a',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/560aeba4340bf2261089eb9c1783f5c3.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f53a90552f87547a15ffb09e0ff35c0',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/806453aad65c055c9796c82cd2c21aaa.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dcd9cd3c27ea89c064af7b030d38139',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/ec143b7cf6cb80124c35461be15a7825.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90b59000eb273d4149e6c7200bcd82be',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/fed3c690efcd0c4e42d1c3b8dc2d956e.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1fc2527078f1acced65ca4a084a3539',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/8c6ec34f4a6e1891bb10941afd3763ec.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f81851e4fdc82ace30176ea833715ef1',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/9a5672806baaa00cef77ac63b0c0ace0.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd37813ca7a7b2555edb90ee458ba5a7',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/f0c4cb2b2fd2858e94e025640cd603d7.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07fc8cdaf59ada41aef805e2ca359fe4',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/c10d563f2014151e022dc43ea3f7044e.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96cfc3c966511635eb13af58f56dbb36',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/897eeeb62a59d06d520fe4c250ad8f30.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3deb7f09e595fc625b7ae470d5e01ff5',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/bb8067bc8d9f8db45c11ffd7282993b1.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02c85e8311dd57619dcdfecbfdfc7e40',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/703ed1e4e68edea2c7b081a0cc2483f4.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b3711e2c992938ae7c444e7d2f82c99',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/84f8b77f0fbd98366c3bad263e29b6c8.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ddbb5e2b7b4e6df13e2eff9e66255da',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/1b3da2a761fae6e92cd8ad54d8a4ae91.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3680f6e2748fa1703d960fb754fc1a3a',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/fcd034f0d23f863aa61f2d827821cede.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c85c6fe2f63cd666ae43a8ea2261d8d9',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/56aafc467abb94924744b7528df4f140.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b39c9d1027186969773dac65f694c31',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/367e01dccb007a7d8e49d26c9ceee37c.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9474cbc08a5128c571d3710a4d4a0c41',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/2966f747a367ae64a13e48c062a02b29.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9d6edb984637bea3ebb38ad26b3bbb3',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/6fe8363b627bbc46de87e94f4f6122f8.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1defc58133dc410afc43c335c2ca1126',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/e1d3884b8b2ef3a4fa7c5c42f4e1f987.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2b93ab44793ccae19d600082b10bfd6',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/119935c41138e115b9a7c16ebf7a2358.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b30eb221c030d2a8bdd186319a05c8e',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/8e2b4025683cf3812c7265fb204b0288.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5c482c41fd864e656bc16550130ba34',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/a822a5961f86aed77ca4bead808b08ad.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94e0facc78ae0d8bb243362fab5c83d5',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/862f56f1e4c5cef699b07841c7844f15.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a099679f7592ddeed1e9bd01526a817',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/e675f79adf86dd2ca336bb1a35d14eed.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b3ea76d34ae1b4eab0b4c1a1c18db87',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/5629ddd42f6b628126d2f8e3e56a2f25.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '584643f30b6b18b26b5ba0409e0bf390',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/3ad35acfbecb8c5e3167cca3541a9768.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf3b7dc3886be6fe614c1d98b9f3e185',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/4ffe676b3426b6cd3209970033252c6e.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5673dc6a866e813efa15ca59a056a03',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/ec341b60fd47833a946c660028a1be57.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecdb33e07e39894ce6f628b5cd5fba3f',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/4ed8d9772541b8ea322ef04e1b583fbe.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cbe66dea709777034f3f75671922bbc',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/6b113a1f5186416615a3cb57ed14a6f9.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '364098ff0a1bc0d550d2e2bc095ab85f',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/c3262a3970313a306a00dd7f37ea61d8.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '027ffaa6aed39c82c196a71a6cc7a665',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/2137f635cb568f497350788413c70d58.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd755078c079f11ccfd48e89c03b328e',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/2b95d2c95b95e0dce6f7b88a6dbb6055.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fe90a403353ff7b80239f45ce792f40',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/c0acfed4f4a6828b63034e468ca8710a.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17151a54133f53cac7d3dee48d37f86e',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/32d39cc59baec7d28e5d869244dd3193.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ee51d9050b872ed02619d2743752b52',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/c84e80e50f1fc7ed0ce39125575487c7.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75bd688fd55be262801fcfbb4412f2c3',
      'native_key' => 'discuss.users_can_remove_own_posts',
      'filename' => 'modSystemSetting/926f6956b03da9bb62a42d34ae7d71bc.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '951e3489c13bf76661b1804b699a82d9',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/295cb00ee1fb912812ede0bfc2b0688a.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa0979159dd7bea188f04a07f2b6ab63',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/b955a679a97d6ced0c90a9adc61ecdc7.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b097186193c52bae8308f5e0c3478c8',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/7fe79f9247667b80eb8a7a9a7ccd5088.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd1d0d0c6fd01641e117ef0e83edcef2',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/9314e47e4dd8c5062817803919f435aa.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c75a212dbd22b16821735cc6a087511',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/13e31d4ccc8dd72dfb0d8c995d13066d.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7964f48da0bc4f1c0453321a7fc8e290',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/f0677fa6600bd00ecfd33e2a22ae1fb2.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2b3d54d8681341ffbbce2faffe70f06',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/72c4ffd89ad7a8e172ef402162868708.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa505c8397c9b9432dd493aa3c7b67e1',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/ce106d3e25e1041792794433feb87752.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93227eee9f0f3b731d7b55fc3825b982',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/5cf5cd8b90b202fd0600b6bdeb6d26f7.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffa67974be38a694f11b9bc68076db90',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/044c26e7628ddd22bcebf5ca552c7ec1.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87e5cda68dbf85cc7d89430fd476ee66',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/4f57b054bbb5b62a397d35396dbc0214.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89868bfb562c3d388a54d7196b1fd90d',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/d1d250dc5ae080132ed933c18a822500.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58e2026249e76664e49570c3b94dc4db',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/f7f3a2925ce13ff4f15120678ec7ac33.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93726c457e24badc94b2748e33dcd990',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/4ffe8b2c51b1bb64cbf0ad62ded5efff.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ebb37289544ccbadb460958434df676',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/19d10e6f9f122018824306b2f8617f9d.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d29a038b7cb5ef933d5329271fc683d',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/bbbe5bf10fc8d19f37ef9006a2964d6b.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '871916fecdd1e0e5f0df6ec0f7c4a35c',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/a2764e0ab39492d76028bf7b90354bd3.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53baa30c4501964cfaa694da990e490f',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/62c984a8c7638503a89a7dcdc58e4b46.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b6e87112596a5f30d9c354169b76a85',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/f28dff19cf2f604f27fd3b3e1c996564.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ba0cf1e6b49a180def054beabcc6235',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/9c2ea9b6d471adb274b3f606d68389f1.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9bf52ba64414d0488bdce92a1e37fd0',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/fc415c8922b1da620f4cd5ebb4670a2a.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12bafba02bb7c91d1c5c577c31c063e4',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/77b7c5c9942d97dfdfb8e838d35d8eb4.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '527cb9912fdfc1821409c328d6578070',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/e117dbab8572fe174505b148d31cc4da.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50b0b68748cbc2b0837cbb4ba323f69b',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/d32b753141dd003b3644b970b38c486d.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33387caa3ab04ec9fcc5a8fca0c12872',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/50ef16cfff4baf2234dcdc4d74bf248a.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d62608d1989eb0fe917e7c59df4c70f',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/fa0b082968f400c7f1267076155a6d3a.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddb7c082c1633a07f6fe6e0f6141e7f9',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/3e0dd93f9f453ff97ffbdf654c67e410.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5446f170f4ba9f891cd2c164e52067ab',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/6497efb7cf28d2b2317cbaec6fd1bd70.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '014861c51e207cd99078975dc235e36d',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/bc5e041689236ff280b65406bbf0ac52.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2a95967cd153dfbd1f602cdba9d4e25',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/31978fb6ba99efe9560d7d9d38a7ffa9.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7d4f372d7e5e2d5bb5fbcba0d9715c0',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/274bbf41960a8ab305fd88651948b412.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc4223454be94644f14ddd30512d4f85',
      'native_key' => 'discuss.session_ttl',
      'filename' => 'modSystemSetting/21009024046aa42cbcb70171184b2523.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20231a6e685d7ab00ee6b5a6a002adc3',
      'native_key' => 'discuss.strip_remaining_bbcode',
      'filename' => 'modSystemSetting/9c39b11264fe2f653c0708129021fbea.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0ba55abc845bbfe270023e0096624db',
      'native_key' => 'discuss.group_by_thread',
      'filename' => 'modSystemSetting/6200dee78795b4abe04ee4af9feb35fb.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d873255b88f47d1ceb24050d48a0b82',
      'native_key' => 'discuss.max_search_results',
      'filename' => 'modSystemSetting/53d427f941270a515ddb7830affa9575.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '228cfb0b72a8485ff7121e3d1b6ed685',
      'native_key' => 'discuss.search_results_buffer',
      'filename' => 'modSystemSetting/8846ce128eb9bef5a8c9aeac6fcf32a2.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e446e82d0623449daef6d917f71e9d4',
      'native_key' => 'discuss.sphinx.host_name',
      'filename' => 'modSystemSetting/45fee61dd293b650be71e692df8b7b2a.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e499f4b28b96cc705b512c224cf3f68f',
      'native_key' => 'discuss.sphinx.port',
      'filename' => 'modSystemSetting/a18a3418e822b94145208a9372cedd31.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '620ab2eccfa47e363b96500bf03a393d',
      'native_key' => 'discuss.sphinx.connection_timeout',
      'filename' => 'modSystemSetting/0f90e35ad2d8f2cd702a5d62771d0e71.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf86e262dd0e723249b9fa4852544f6f',
      'native_key' => 'discuss.sphinx.searchd_retries',
      'filename' => 'modSystemSetting/9aee1b45fe6d0442c0dcbdc214148e68.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '760065ec75f2fb0459ba3877c6d8be33',
      'native_key' => 'discuss.sphinx.searchd_retry_delay',
      'filename' => 'modSystemSetting/6018a26ff3ba911b031062e6b25517e9.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a31a94b3662b84beab1c04b8fccea60b',
      'native_key' => 'discuss.sphinx.indexes',
      'filename' => 'modSystemSetting/a90dfde9eba20e9e25157c4cb441225c.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '73b3921395de3d1fe55a80917ee4c473',
      'native_key' => NULL,
      'filename' => 'modUserGroup/94e830e4b4a0445c4c42c638744e0d4f.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'fcb73038e770d63bebd1a86df2070978',
      'native_key' => NULL,
      'filename' => 'modUserGroup/bd92cdbeba594fe0438dc0bd7219d587.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c7f680031d5cd8724679b82a37df890',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/a8effb77fbc9ef58a41b352044f13fc2.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cefd7e747fae2b136b0251d93f58e88',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/d79dba051ca5ea02fa15d490d78b8140.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f04f861cbca62b210e673d8b018dbeb8',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/9fa15fe9b6ec01528d92b267829625d3.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '048637897ca99d3508a2e31e8b9c44b6',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/bc6ca299e6a047a9e6b9d31ef8b2b518.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cfc0ba7fd1938ec3e1ba0d845c63bf5',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/9f2de5703645a9022e06893eb73c2953.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97f517b68a3fdb4c79de4b286860494a',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/46744dbb6ec514be78349bc1f5c7bd41.vehicle',
      'namespace' => 'discuss',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7aff5629ea856237f0fab043a20a7e2f',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/a44b19a3b6e4116568ccda946c5a2fe2.vehicle',
      'namespace' => 'discuss',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c079340cc031780268d4a37f9c5c430',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/33d9494e4b02d2b320c6868765734ebc.vehicle',
      'namespace' => 'discuss',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70a851ac5df387e65cc29f2608b426eb',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/040987d0e244ba647ebba1aa53fe758b.vehicle',
      'namespace' => 'discuss',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cef992804bb1cf8d65dd3ddc966a30ac',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/7b3d61313d0dc2ffd0448034e6250127.vehicle',
      'namespace' => 'discuss',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '510a928708f7f4395605c196b0e12c31',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/a4ad9862c20a07fffcc60265f181c7a8.vehicle',
      'namespace' => 'discuss',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7285d5415767752dcfd92557179f28f1',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/c0279f03d6d94cbedfcd8dde9d2ad695.vehicle',
      'namespace' => 'discuss',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5dc2af1d3ef71b11b11ff86dbb901565',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/9206493978935e566475c974976ec3fe.vehicle',
      'namespace' => 'discuss',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9395624f25362595a51f6623bb096dff',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/61c141a56d0d17d2403b0ffca9c045c3.vehicle',
      'namespace' => 'discuss',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c25c89577864fb1f50adc784ef305461',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/8206d10cb562b9782990b900e3811e84.vehicle',
      'namespace' => 'discuss',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95ae2c63a84aec8af17ae42e2b54068b',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/0a3ccfa9f610e635db23cb96480cd457.vehicle',
      'namespace' => 'discuss',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66b5a7272f7e4e733d450e4eaba403c6',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/aea01f3920d55d39817127e7c0c44d89.vehicle',
      'namespace' => 'discuss',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5e53dac7111fa016bddbf0fbfd7d00a3',
      'native_key' => 'discuss',
      'filename' => 'modMenu/f4cd638801fa2b04f64434bdf3effb63.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);